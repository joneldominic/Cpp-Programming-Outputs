#include <iostream>
#include <stdio.h>  //pra mka gamit sa gets()
#include <stdlib.h> //para mka gamit og system commands
#include <ctime>    //para mka gamit og time
#include <string>
#include <cstdio>
#include <cstdlib>
using namespace std;


int input;
char loop;
time_t now = time(0);
char* dt = ctime(&now);

int main(void)
{

   do
   {
    system ("cls");

   cout<<"Jonel Dominic E. Tapang";
   cout<<"\t\t Exercise #10";
   cout<<"\t\t"<<dt<<endl<<endl;
   cout<<"This program is the combination of simple linear programming to looping constructs."<<endl<<endl;
   cout<<"To start, select one of the choices below"<<endl;
   cout<<"1 - Reverse Pyramid"<<endl;
   cout<<"2 - Converter"<<endl;
   cout<<"3 - Strings"<<endl;
   cout<<"Choice[0 to exit]: ";
   cin>>input;

   if (input==1)
        {
            system ("cls");

            cout<<"Jonel Dominic E. Tapang";
            cout<<"\t\t Exercise #10";
            cout<<"\t\t"<<dt<<endl;

            int row;

            cout<<"\n**********************************You pressed(1)**********************************"<<endl;
            cout<<"Starting Triangle pattern..."<<endl<<endl;
            cout<<"Enter number of rows: ";
            cin>>row;





        }

    if (input==2)
        {
            system ("cls");

            cout<<"Jonel Dominic E. Tapang";
            cout<<"\t\t Exercise #10";
            cout<<"\t\t"<<dt<<endl;

            int bin;
            int sum;
            int rem = 0;
            int dec;
            int num = 1;

            cout<<"\n**********************************You pressed(2)**********************************"<<endl;
            cout<<"Decimal to binary conversion..."<<endl<<endl;
            cout<<"Enter a decimal number: ";
            cin>>dec;
            cout<<"Decimal number "<<dec<< " is equal to ";
            do
                {
                    rem = (dec%2);
                    sum = sum + (num*rem);
                    dec = dec/2;
                    num = num * 10;
                }
                    while (dec!=0);
            cout<<sum<<" in binary";
        }

    if (input==3)
        {
            char name3[50];
            char adds[50];
            char age [3];
            system ("cls");

            cout<<"Jonel Dominic E. Tapang";
            cout<<"\t\t Exercise #10";
            cout<<"\t\t"<<dt<<endl;
            cout<<"\n**********************************You pressed(3)**********************************"<<endl;
            cout<<"String echo..."<<endl<<endl;
            cin.get();  //para dli mag error nig input
            cout<<"What is your name: ";
            gets(name3);
            cout<<endl<<"Hello there "<<name3<<".";
            cout<<" How old are you? ";
            gets(age);
            cout<<endl<<name3<<", you are already "<<age<<" years old."<<endl<<endl;
            cout<<"Where do you live "<<name3<<"? ";
            gets(adds);
            cout<<endl<<name3<<", you are living in "<<adds<<"."<<endl<<endl;
            cout<<"Thank you for using the program "<<name3<<".";
            cout<<" Have a nice day!"<<endl<<endl<<endl;
        }

    if (input==0)
        {
            system ("cls");

            cout<<"Jonel Dominic E. Tapang";
            cout<<"\t\t Exercise #10";
            cout<<"\t\t"<<dt<<endl;
            cout<<"\n*************************Thank you for using the program.*************************"<<endl;
            return 0;
        }

    if (input<0| input >3)
        {
            system ("cls");

            cout<<"Jonel Dominic E. Tapang";
            cout<<"\t\t Exercise #10";
            cout<<"\t\t"<<dt<<endl<<endl;
            cout<<"*******************Invalid entry. Program only accepts (0,1,2,3)*******************";
        }





        cout<<endl<<endl;
        cout<<"Do you want to try again [Y-yes | N-no]: ";
        cin>>loop;
    }
        while (loop == 'Y' or loop == 'y');         //do..while loop para mag dipindi sa user ang number of looping
        system("PAUSE");
        return 0;
}
