#include <iostream>
#include <stdlib.h>
using namespace std;

int main(){
       char grade;
    for(;;){
        system ("cls");
        cout<<"Enter your grade: ";
        cin>>grade;
       switch (grade)
       {
            case 'A':
                cout<<"Excellent!"<<endl;
            break;

            case 'B':
            case 'C':
                cout<<"Well done"<<endl;
            break;

            case 'D':
                cout<<"You passed"<<endl;
            break;

            case 'F':
                cout<<"Better try again"<<endl;
            break;

            default:
                cout<<"Invalid grade"<<endl;
        }
            cout<<"Your grade is "<<grade<<endl;
            system ("pause");
    }

}
