#include <iostream> //nag supportog mga conversions between text, input and output
#include <stdio.h>  //pra mka gamit sa gets()
#include <stdlib.h> //para mka gamit og system commands
#include <ctime>    //para mka gamit og time


using namespace std;




int choice; //pra sa main input
char retry; //pra sa input as decision for looping
//declarations for the converter
int bin;
int sum;
int rem;
int num = 1;


int main(void)
    {

        system("Title Jonel Dominic Tapang    Exercise #10"); //para ang title sa application mao usob og Jonel....Exer..#10
          do     //diri mag start ang pag loop if ma meet ang decision sa "while"
            {
                    system ("cls"); //for clearing the screen
                    time_t now = time(0); //declaration for time
                    char* dt = ctime(&now); //delcaration for time
                    cout<<"Jonel Dominic E. Tapang";
                    cout<<"\t\t Exercise #10";
                    cout<<"\t\t"<<dt<<endl<<endl;
                    cout<<"This program is the combination of simple linear programming to looping constructs."<<endl<<endl;
                    cout<<"To start, select one of the choices below"<<endl;
                    cout<<"1 - Reverse Pyramid"<<endl;
                    cout<<"2 - Converter"<<endl;
                    cout<<"3 - Strings"<<endl;
                    cout<<"Choice[0 to exit]: ";
                    cin>>choice;

            switch(choice)
                {
                    case 1:
                        system("cls");
                        cout<<"Jonel Dominic E. Tapang";
                        cout<<"\t\t Exercise #10";
                        cout<<"\t\t"<<dt<<endl;

                        int rows,x,y,space;

                        cout<<"\n**********************************You pressed(1)**********************************"<<endl;
                        cout<<"Starting Triangle pattern..."<<endl<<endl;
                        cout<<"Enter number of rows: ";
                        cin>>rows;
                        cout<<endl;
                        cout<<"Below is the pattern..."<<endl<<endl;
//study
                        for(x=rows;x>=1;x--)
                            {
                                for(space=0;space<rows-x;space++)
                                cout<<"  ";
                                for(y=x;y<=2*x-1;y++)
                                cout<<"* ";
                                for(y=0;y<x-1;y++)
                                cout<<"* ";
                                cout<<endl;
                            }

                    break;


                    case 2:
                        system("cls");
                        cout<<"Jonel Dominic E. Tapang";
                        cout<<"\t\t Exercise #10";
                        cout<<"\t\t"<<dt<<endl;

                        int dec;


                        cout<<"\n**********************************You pressed(2)**********************************"<<endl;
                        cout<<"Decimal to binary conversion..."<<endl<<endl;
                        cout<<"Enter a decimal number: ";
                        cin>>dec;
                        cout<<endl;
                        cout<<"Decimal number "<<dec<< " is equal to ";
                        do
                            {
                                rem = (dec%2);
                                sum = sum + (num*rem);
                                dec = dec/2;
                                num = num * 10;
                            }
                        while (dec!=0);
                        cout<<sum<<" in binary";
                        cout<<endl<<endl;
                    break;


                    case 3:

                        system("cls");
                        cout<<"Jonel Dominic E. Tapang";
                        cout<<"\t\t Exercise #10";
                        cout<<"\t\t"<<dt<<endl;


                        char name[50];
                        char address[50];
                        char age [3];

                        cout<<"\n**********************************You pressed(3)**********************************"<<endl;
                        cout<<"String echo..."<<endl<<endl;
                        cin.get();  //para dli mag error nig input(nganong mo error mn jud ni)
                        cout<<"What is your name: ";
                        gets(name);
                        cout<<endl<<"Hello there "<<name<<".";
                        cout<<" How old are you? ";
                        gets(age);
                        cout<<endl<<name<<", you are already "<<age<<" years old."<<endl<<endl;
                        cout<<"Where do you live "<<name<<"? ";
                        gets(address);
                        cout<<endl<<name<<", you are living in "<<address<<"."<<endl<<endl;
                        cout<<"Thank you for using the program "<<name<<"."<<endl;
                        cout<<"Have a nice day!"<<endl<<endl<<endl;
                    break;


                    case 0:

                        system("cls");
                        cout<<"Jonel Dominic E. Tapang";
                        cout<<"\t\t Exercise #10";
                        cout<<"\t\t"<<dt<<endl<<endl<<endl;
                        cout<<"\n*************************Thank you for using the program.*************************";
                        cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl; //pra dli mag dikit nag "press any key"
                        system("pause");
                        return 0; //para modritso nag exit,. dli na mohapit sa loop decision.

                    break;


                    default:    //if wala sa 4 cases ang g input as choice, dri maoy mogawas dyun
                        system("cls");
                        cout<<"Jonel Dominic E. Tapang";
                        cout<<"\t\t Exercise #10";
                        cout<<"\t\t"<<dt<<endl<<endl;
                        cout<<"*******************Invalid entry. Program only accepts (0,1,2,3)*******************";
                    break;
                }

                       cout<<endl<<endl;
                        cout<<"Do you want to try again [y-yes | n-no]: ";
                        cin>>retry;
            }
            while (retry == 'Y' or retry == 'y');         //do..while loop para mag dipindi sa user ang number of looping
            system("pause");
    }

//Jonel Dominic E. Tapang BSCS-1
