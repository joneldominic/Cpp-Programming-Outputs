#include <iostream>
#include <stdlib.h>
# include <stdio.h>
using namespace std;






int main(void)
    {
        system ( "TITLE JZCybernookCalc-v2.0" );
        system ( "COLOR" );
        char cChar;
        double dfirstnumber;
        double dsecondnumber;
        char cDoagain;

        do
    {
        system ("cls");
        cout<<"@dneljo@yahoo.com \t \t \t \t JZ Cybernook:Calculator \n\n";
        cout<<"\t\tThis program is exclusive only for JZ Cybernook\n\n";

        cout << "Enter your first number:";
        cin >> dfirstnumber;
        cout<< "\nChoose operation you want to use:"<<endl;
        cout<< "\n\t\t\t\t Press (+) to ADD"<<endl;
        cout<< "\t\t\t\t Press (-) to SUBRACT"<<endl;
        cout<< "\t\t\t\t Press (*) to MULTIPLY"<<endl;
        cout<< "\t\t\t\t Press (/) to DIVIDE"<<endl;
        cout<< "OPERATION:";
        cin >> cChar;
        cout<< "\nEnter your second number:";
        cin >> dsecondnumber;

    switch (cChar)
    {
            cout<< "\tRESULTS:"<<endl;
            case '+':
                cout << "\n\t\t\t\t The SUM is: "<< (dfirstnumber + dsecondnumber) << endl;
                break;
            case '-':
                cout << "\n\t\t\t\t The DIFFERENCE is: " << (dfirstnumber - dsecondnumber) << endl;
                break;
            case '*':
                cout << "\n\t\t\t\t The PRODUCT is: " << (dfirstnumber * dsecondnumber) << endl;
                break;
            case 'x':
                cout << "\n\t\t\t\t The PRODUCT is: " << (dfirstnumber * dsecondnumber) << endl;
                break;
            case 'X':
                cout << "\n\t\t\t\t The PRODUCT is: " << (dfirstnumber * dsecondnumber) << endl;
                break;
            case '/':
                if(dsecondnumber == 0)                  {
                cout<< "\t\t*INVALID OPERATION." << endl;}
                else{
                cout << "\n\t\t\t\t The QOUTIENT is: " << (dfirstnumber / dsecondnumber) << endl;

        }
                break;
                default:
                cout << "\t\t*INVALID OPERATION." << endl;
                break;
        }
                cout << "\n\n*Would you like to continue using this program? (Y/N)";
                cin >>  cDoagain;
    }while (cDoagain == 'Y' or cDoagain == 'y');
    system("PAUSE");

    return 0;

    }



