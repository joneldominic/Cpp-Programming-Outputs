#include<iostream>
#include <cstdlib>
using namespace std;

int main(void)
{
    system ( "TITLE Calculator" );
    system ( "COLOR 2" );
    char cChar;
    double dfirstnumber;
    double dsecondnumber;
    char cDoagain;

    do
    {
        system("CLS");
        cout << "Please enter the first number you would like to use."<< endl;
        cin >> dfirstnumber;
        cout<< "Please enter the operation you would like to perform."<< endl;
        cout<< " (+,-,*,or /)" << endl;
        cin >> cChar;
        cout<< "Please enter the second number you would like to use." << endl;
        cin >> dsecondnumber;

        switch (cChar)
        {
            case '+':
                cout << "The answer is: " << dfirstnumber << "+" << dsecondnumber << "=" <<
                (dfirstnumber + dsecondnumber) << endl;
                break;
            case '-':
                cout << "The answer is: " << dfirstnumber << "-" << dsecondnumber << "=" <<
                (dfirstnumber - dsecondnumber) << endl;
                break;
            case '*':
                cout << "The answer is: " << dfirstnumber << "*" << dsecondnumber << "=" <<
                (dfirstnumber * dsecondnumber) << endl;
                break;
            case 'x':
                cout << "The answer is: " << dfirstnumber << "x" << dsecondnumber << "=" <<
                (dfirstnumber * dsecondnumber) << endl;
                break;
            case 'X':
                cout << "The answer is: " << dfirstnumber << "X" << dsecondnumber << "=" <<
                (dfirstnumber * dsecondnumber) << endl;
                break;
            case '/':
                if(dsecondnumber == 0){
                cout<< "That is an invalid operation." << endl;}
                else{
                cout << "The answer is: " << dfirstnumber << "/" << dsecondnumber << "=" <<
                (dfirstnumber / dsecondnumber) << endl;

        }
                break;
                default:
                    cout << "That is an invalid operation." << endl;
                    break;
    }
                cout << "Would you like to start again? (Y/N)" << endl;
                cin >>  cDoagain;
    }while (cDoagain == 'Y' or cDoagain == 'y');
    system("PAUSE");
    return 0;
}
