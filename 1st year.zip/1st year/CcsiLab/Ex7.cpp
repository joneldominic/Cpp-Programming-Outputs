#include <iostream>
#include <cstdlib>
#include <stdio.h>

using namespace std;


char name [50];
char id [50];
char crs[50];
char yr[20];
char ads [50];
char bd [20];
char cn [11];
char motto [50];


int main(){
        system("Title Exercise #7");
        system("cls");

        cout<<"Jonel Dominic E. Tapang";
        cout<<"\t\t\t\t\t\tExercise #7"<<endl;
        cout<<"\nInput the following fields"<<endl;
        cout<<"\nStudent name: ";
        gets(name);
        cout<<"Student ID number: ";
        gets(id);
        cout<<"Course: ";
        gets(crs);
        cout<<"Year: ";
        gets(yr);
        cout<<"Permanent Address: ";
        gets(ads);
        cout<<"Birthday: ";
        gets(bd);
        cout<<"Contact number: ";
        gets(cn);
        cout<<"Motto in life: ";
        gets(motto);
        cout<<endl;
        system ("pause");

        system ("cls");
        cout<<" Jonel Dominic E. Tapang";
        cout<<"\t\t\t\t\tExercise 7"<<endl;
        cout<<"\n\tYour name is "<<name<<".";
        cout<<" Your ID number is "<<id<<".";
        cout<<" You are taking up "<<crs;
        cout<<" and you are already in "<<yr<<".";
        cout<<" You live in "<<ads;
        cout<<" and your birthday is on "<<bd<<".";
        cout<<" You can reached through contact number "<<cn<<".";
        cout<<" Your motto in life is "<<motto<<"."<<endl;
        cout<<"\nThank you for using the sample program."<<endl;

        return 0;
    }
