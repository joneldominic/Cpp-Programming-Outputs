#include <iostream>
#include <cstring>

using namespace std;

string Ones(int N)
    {
    string arrOnes[]=
        {" ","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"};
    if(N<20)
        return arrOnes[N];
    else return "error";
    }

    string Tens(int N)
    {
        string arrTens[]={" ","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"};

    if(N<20)
        return Ones(N);
    else if (N<100)
        {
            int tens = N/10;
            int ones = N%10;
            return arrTens[tens-1]+""+Ones(ones);
        }else
            return "error";
    }
string toEnglish(int N)
    {
        if (N<100)
        {
           return Tens(N);
        }
        else if (N<1000)
        {
            int hundreds = N/100;
            int tens = N%100;
            return Ones(hundreds) + "hundreds" + Tens(tens);
        }
        else if (N<1000000)
        {
            int thousand = N/1000000;
            int hundreds = N%1000000;
            return toEnglish(thousand) + "thousand" + toEnglish(hundreds);
        }
        else
        {
            int billion = N/1000000000;
            int millions = N%1000000000;
            return Ones(billion) + "billion" + toEnglish(millions);
        }
    }
int main(void)
{
    int number=0;
    cout<<"Enter a number: ";
    cin>>number;
    cout<<number<<" in words: "<<endl;
    cout<<toEnglish(number)<<endl;
}
