#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    char str1[10] = "Hello";
    char str2[10] = "World";
    char str3[10];
    int len;

    // copy str1 into str3 (gecopy ang str1 ngadto sa str3)
    strcpy(str3,str1);
    cout<<"strcpy(str3,str1): "<<str3<<endl;

    //concatenates str1 and str2 (esumpay ang str1 og str2)
    strcat(str1,str2);
    cout<<"strcat(str1,str2): "<<str1<<endl;

    //total length of str1 after concatenation (balik sa length sa str1)
    len = strlen(str1);
    cout<<"strlen(str1): "<<len<<endl;

    return 0;
}
