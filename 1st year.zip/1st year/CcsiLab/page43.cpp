#include <iostream>
#include <cstring>
using namespace std;

int main(void)
{
   char vsu[]="VISAYAS STATE UNIVERSITY";
   int length = strlen(vsu);
   char usv[length];
   int pos = 0;
   do
   {
       --length;
       usv[pos] = vsu[length];
       pos++;
   }
        while (length>0);
        usv[pos]='\0';
        cout<<"Original "<<vsu<<endl;
        cout<<"Reverse "<<usv<<endl;

    return 0;
}
