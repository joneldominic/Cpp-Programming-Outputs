#include <iostream>
using namespace std;
//This program shows the difference between
/*signed amd unsigned integers.*/
int main() {
    short int i;    //a signed short integer
    short unsigned int j;   //an unsigned short integer
    j=50000;
    i=j;
    cout<<"the value of i is: "<< i <<endl;
    cout<<"the value of j is: "<< j <<endl;
    return 0;
}
