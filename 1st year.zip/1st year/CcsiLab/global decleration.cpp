#include <iostream>
using namespace std;

//global variable decleration:
int g = 20;
int main() {

    //local variable decleration:
    int g = 10;
    cout <<"g="<<g <<endl;
    cout<< "Input a new value for g:";
    cin>> g;
    cout<<"\nThe new value of g is : "<<g;
    return 0;
}
