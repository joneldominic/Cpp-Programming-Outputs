#include <iostream>
#include <stdlib.h>
# include <stdio.h>
using namespace std;



float x;
float y;
float c;
float n,circ, area, volume;
char unitxt[1];
char r ;
char S;


int main() {

            do{
        system ("cls");
        cout<<"@dneljo@yahoo.com \t \t \t \t JZ Cybernook:Calculator \n\n";
        cout<<"\t\tThis program is exclusive only for JZ Cybernook\n\n";



            {
            cout<<" \nInput your first number:";
            cin>> x;
            cout<<" \nInput your second number:";
            cin>> y;

            int o;
            cout<<"\n\t\t   \tPress 1 = add";
            cout<<"\n\t\t   \tPress 2 = subtract";
            cout<<"\n\t\t   \tPress 3 = divide";
            cout<<"\n\t\t   \tPress 4 = multiply";
            cout<<"\n\n Operation:";
            cin>> o;

            if (o == 1)
    {
            cout<<"\t\t\t\tRESULT: "<<x+y<<endl;
    }

            else if (o == 2)
    {
         cout<<"\n\n\t\t\t\tRESULT: "<<x-y<<endl;
    }
            else if (o == 3)
    {
         cout<<"\n\n\t\t\t\tRESULT: "<<x/y<<endl;
    }

            else if (o == 4)
    {
         cout<<"\n\n\t\t\t\tRESULT: "<<x*y<<endl;

    }
            else if (o > 4)
    {
                cout<<"\n\t\t\t>>You Entered an 'Invalid Key'<<";
    }
            int a;
            cout<<"\n\n\n*To 'CONTINUE' using program: Enter '1'";
            cout<<"\n*To 'CLOSE' the program     : Enter '0'";
            cout<<"\n\nCommand:";
            cin>>c;

            system("pause");

        }
    }


    while (c!=0);

    cout<<"\n\n\n\t\tTHANK YOU FOR USING @Keenz creations. God Bless!\n";
    cout<<"\t\t(c)dneljo@yahoo.com\n";
        return 0;
    }




