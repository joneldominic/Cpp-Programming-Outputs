#include <iostream>
#include <stdlib.h>
using namespace std;


#define pi 3.1416

float x;
float y;
float c;
float n,circ, area, volume;
char unitxt[1];
char r ;
char S;


int main() {

            do{
        system ("cls");
        cout<<"@Jonel Dominic E. Tapang \t \t \t JZ Cybernook:Calculator \n\n";
        cout<<"\t\tThis program is exclusive only for JZ Cybernook\n\n";
        cout<<"*To EXIT this program: Use 0 (zero) as your inputs|\n\n";

            {
            cout<<" \nInput your first number:";
            cin>> x;
            cout<<" \nInput your second number:";
            cin>> y;
            cout<<"\n\t\tRESULTS:\n";
             c=x+y;
            cout<<"\t\t\t\tAddition:" <<c<<endl;
             c=x-y;
            cout<<"\n\t\t\t\tSubraction:" <<c<<endl;
             c=x/y;
            cout<<"\n\t\t\t\tDivision:" <<c<<endl;
             c=x*y;
            cout<<"\n\t\t\t\tMultiplication:" <<c<<endl;

            system("pause");
        }
    }while (c!=0);
    cout<<"\n\n\nThank you for using this program. Good day!\n";
        return 0;
    }




