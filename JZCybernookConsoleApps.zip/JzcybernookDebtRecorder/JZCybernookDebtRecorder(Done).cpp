#include <iostream>
#include <string>
#include <fstream>
#include <cstdio>
#include <cstdlib>

using namespace std;

void input();
void searchname();
void searchage();
void searchsalary();
void quit();
void displayall();
void search();
void deleteFile();
void editFile();

int main(){


   system ("title JZCybernook::Debt Recorder");
   system ("cls");
   system ("color 0F");
   cout<<"@dneljo@yahoo.com \t \t \t \t JZ Cybernook:Debt Recorder \n\n";

       int choice;
       cout << "\n\nPress (1) Input new Debtor" << endl;
       cout << "Press (2) View Records of Debtors" << endl;
       cout << "Press (3) Clear Records" << endl;
       cout << "Press (4) Edit Records" << endl;
       cout << "Press (5) Exit Program" << endl;
       cin >> choice;

switch (choice){
       case 1:
            input();
            break;
       case 2:
            search();
            break;
       case 3:
            deleteFile();
            break;
       case 4:
            editFile();
            break;
       case 5:
            quit();
            break;

       cin.get();


        }
        }
void editFile()
{
 string name, input,decision;

 long int Date;
 float Credit,newDebt;
 ifstream employee("newemployee.txt");
 if (!employee.eof()){
employee >> name >> Date >> Credit;
}
 system("cls");

 cout << "Enter the name of Debtor:";
 cin >> input;

 if (input == name)
 {

     cout << name << ' ' << Date << ' ' << Credit << endl;
     cout << "Is this the correct Debtor[y][n]:";
     cin >> decision;
     if (decision == "y"){
     cout << "Enter the new amount of Credit:";
     cin >> newDebt;
     Credit = newDebt;
           }

     employee.close();
     }

     ofstream employee2("newemployee.txt", ios::app);
     employee2 << name << ' ' << Date << ' ' << Credit << endl;
     employee2.close();
 system("pause");
 main();
     }

void input()
{
 string name;
 long int Date;
 float Credit;
 ofstream newemployee("newemployee.txt", ios::app);
 system("cls");
 cout << "Enter the new Debtors name" << endl;
 cin >> name;
 cin.sync();
 system("cls");
 cout << "Enter the date of Credit." << endl;
 cin >> Date;
 system("cls");

 cout << "Enter the amount of Credit" << endl;
 cin >> Credit;


 newemployee << name << ' ' << Date << ' ' << Credit << endl;
 newemployee.close();
 main();
     }
void searchname()
{
     ifstream employee("newemployee.txt");
     string name;
     string str, line;
     long int Date, offset;
     float Credit;
     system("CLS");
     cout << "Enter the Debtors name:";
     cin >> str;

     while (employee >> name >> Date >> Credit){
           if (str == name){
     system ("CLS");
     cout << "Debtor found" << endl;
     cout << "Name" << ' ' << "Date" << ' ' << "Credit" << endl;
     cout << "---------------" << endl;
     cout << name << ' '<< Date << ' ' << "P" <<  Credit << endl;
     }
     }


     while (employee >> name ){
                 if (str != name){
                 system ("CLS") ;
                 cout << "Nobody under that name exists" << endl;

                      }
                      }
     system ("pause");
     main();


 }
void searchage()
 {
     ifstream employee("newemployee.txt");
     string name;
     long int Date ;
     long int fage;
     float Credit;
     system ("CLS");
     cout << "Enter the date of credit:";
     cin >> fage;
     while (employee >> name >> Date >> Credit){
           if (fage == Date){
                    system ("CLS");
                    cout << "Debtor(s) found" << endl;
                    cout << "Name" << ' ' << "Date" << ' ' << "Credit" << endl;
                    cout << "---------------" << endl;
                    cout << name << ' ' << Date << ' ' << "P" << Credit << endl;
                    }
                    }
     while (employee >> Date){
           if (fage != Date){
                    system ("CLS");
                    cout << "No Debtor(s) found"<< endl;


                    }
           }
           system ("pause");
           cin.get();
           main();
  }
void searchsalary()
{
     ifstream employee ("newemployee.txt");
     string name;
     long int Date ;
     float Credit;
     float fCredit;
     system ("CLS");
     cout << "Enter an amount of Credit:";
     cin >> fCredit;
     while (employee >> name >> Date >> Credit){
           if (fCredit == Credit ){
                       system ("cls");
                       cout << "Debtor(s) found"<< endl;
                       cout << "Name" << ' ' << "Date" << ' ' << "Credit" << endl;
                       cout << "---------------" << endl;
                       cout << name << ' ' << Date << ' ' << "P" << Credit << endl;;

                       }
                       }
     while (employee >> Credit){
            if (fCredit != Credit){
                system ("CLS");
                cout << "No Debtor(s) found" << endl;
                }
           }
     system("pause");
     cin.get();
     main();
 }
void quit()
{
 system ("CLS");
 cout << "Thank you for using the JZCybernook::Debt Recorder" << endl;
 system ("pause");
 cin.get();
     }
void displayall()
{
     ifstream employee("newemployee.txt");
     long int Date;
     float Credit;
     string name;
     system ("CLS");
     cout << "Entire Debt Records"<< endl;
     cout << "Name" << ' ' << "Date" << ' ' << "Credit" << endl;
     cout << "---------------" << endl;
     while (employee >> name >> Date >> Credit){
     cout << name << ' ' << Date << ' ' << "P" << Credit << endl ;
     }
     system ("pause");
     cin.get();
     main();

     }
void search()
{
     long int Date;
     string name;
     float Credit;
     int choice2;
     system ("CLS");

     cout << "1.Search by Name" << endl;
     cout << "2.Search by Date" << endl;
     cout << "3.Search by amount of Credit" << endl;
     cout << "4.Display all Debtors" << endl;
     cout << "5.Back" << endl;
     cout << "6.Exit program" << endl;
     cin >> choice2;

     switch (choice2){
            case 1:
                 searchname();
                 break;
            case 2:
                 searchage();
                 break;
            case 3:
                 searchsalary();
                 break;
            case 4:
                 displayall();
                 break;
            case 5:
                 main();
                 break;
            case 6:
                 quit();
                 break;
                 }




            }
void deleteFile()
{

     string decision;
     cout << "Are you sure?[Y]es[N]o" << endl;
     cin >> decision;
     if (decision == "y"){
     ofstream employee("newemployee.txt");
     system("cls");
     cout << "Successfully Completed!" << endl;
     system("pause");
     employee.close();
     main();
     }
     else{
          main();
          }
     }








