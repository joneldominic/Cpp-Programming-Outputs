#include <iostream>
#include <stdlib.h>
# include <stdio.h>
using namespace std;

int pass;
char user [30];
int code1;
int code2;
int code3;
int code4;
int code5;
int code6;
int code7;
int code8;
int code9;

main()
{
    cout<<"-------------------------------------------------------------------------------"<<endl;
    cout<<"---------------------------- MY SECRET INFORMATIONS ---------------------------"<<endl;
    cout<<"-------------------------------------------------------------------------------"<<endl<<endl;
    cout<<"=========Enter Codes==========================================================="<<endl;
    cout<<"Code 1: ";
    cin>>code1;
    cout<<"\n\tCode 2: ";
    cin>>code2;
    cout<<"\n\t\tCode 3: ";
    cin>>code3;
    cout<<"\n\t\t\tCode 4: ";
    cin>>code4;
    cout<<"\n\t\t\t\tCode 5: ";
    cin>>code5;
    cout<<"\n\t\t\t\t\tCode 6: ";
    cin>>code6;
    cout<<"\n\t\t\t\t\t\tCode 7: ";
    cin>>code7;
    cout<<"\n\t\t\t\t\t\t\tCode 8: ";
    cin>>code8;
    cout<<"\n\t\t\t\t\t\t\t\tCode 9: ";
    cin>>code9;

        if (code9+code8+code7+code6+code5+code4+code3+code2+code1==9);
        {
            cout<<"Access Granted";
        }













        if ();
        else






    system("cls");
    cout<<"-------------------------------------------------------------------------------"<<endl;
    cout<<"---------------------------- MY SECRET INFORMATIONS ---------------------------"<<endl;
    cout<<"-------------------------------------------------------------------------------"<<endl<<endl;
    cout<<"=================================INVALID CODES================================="<<endl<<endl;
    cout<<"========================INVALID CODES == INVALID CODES========================="<<endl<<endl;
    cout<<"==================INVALID CODES==INVALID CODES==INVALID CODES=================="<<endl<<endl;
    cout<<"=========INVALID CODES==INVALID CODES == INVALID CODES==INVALID CODES=========="<<endl<<endl;
    cout<<"===INVALID CODES==INVALID CODES==INVALID CODES==INVALID CODES==INVALID CODES==="<<endl;

return 0;
}
