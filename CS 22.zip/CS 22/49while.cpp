#include <iostream>
using namespace std;

int main(){
int a;
    cout<<"Input: ";
    cin>>a;

    while(a<20)
        {
            cout<<"Value of a: "<<a<<endl;
            a++;
        }
        return 0;
    }
