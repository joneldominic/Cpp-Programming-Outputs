#include <iostream>
using namespace std;

int main()
{
    int *ptr;
    int *marker;

    ptr = new int;
    marker = ptr;
    cout << "Enter 5 values: ";
    for (int i=0; i<=4; i++){
      cout << "storing at " << ptr <<endl;
      cin >> *ptr;
      ++ptr;

    }
    cout<<endl;
    ptr = marker;
    for (int j=0; j<=4; j++){
      cout << ptr << " - " << *ptr << endl;
      ++ptr;
    }
    return 0;
}
