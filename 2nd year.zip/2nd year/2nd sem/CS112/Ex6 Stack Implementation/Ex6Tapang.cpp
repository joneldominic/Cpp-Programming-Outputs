//Jonel Dominic E. Tapang
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stack>
#include <cctype>
#include <iostream>

using namespace std;

stack < char > operators;
stack < int > operands;

void operation(char op);
bool hasLowerPriority(char op1, char op2);

bool error;


int main()
{
    char exp[1000], *p;
    int len;

    cout<<"This program will calculate a given balance expression"<<endl;

    while(true)
    {
        cout<<endl<<"**Separate each expression with a spacebar"<<endl;
        cout<<endl<<"Enter a balance expression: ";
        scanf("%[^\n]%*c", exp);
        if(exp[0] == '.') break;

        len = strlen(exp);
        if(len == 0) { getchar(); continue; }
        exp[len] = ' '; exp[len + 1] = ')'; exp[len + 2] = '\0';
        error = false;
        operators.push('(');

        p = strtok(exp, " ");

        while(p && !error)
        {
            if(isdigit(p[0]))
                operands.push(atoi(p));

            else
                switch(p[0])
                {
                    case '(' :  operators.push('(');
                        break;

                    case ')' :  while (!operators.empty() && !error && operators.top() != '(')
                                {
                                    operation(operators.top()); operators.pop();
                                }

                                if (!operators.empty())
                                    operators.pop();
                                else
                                    error = true;
                        break;

                    default  :  while(!operators.empty() && !error && hasLowerPriority(operators.top(), p[0]))
                                {
                                    operation(operators.top()); operators.pop();
                                }

                                operators.push(p[0]);
                }

            p = strtok(NULL, " ");
        }

        if(error || !operators.empty() || operands.size() != 1)
        {
            cout<<"ERROR"<<endl;

            while(!operands.empty())
                operands.pop();
            while(!operators.empty())
                operators.pop();
        }

        else
        {
            printf("%d\n", operands.top()); operands.pop();
        }
    }
    return 0;
}

void operation(char op)
{
    if(operands.size() < 2)
    {
        error = true; return;
    }

    int op2 = operands.top(); operands.pop();
    int op1 = operands.top(); operands.pop();
    switch(op)
    {
        case '+': operands.push(op1 + op2); break;
        case '-': operands.push(op1 - op2); break;
        case '*': operands.push(op1 * op2); break;
        case '/': operands.push(op1 / op2); break;
        default : error = true; return;
    }
}

bool hasLowerPriority(char op1, char op2)
{
    switch (op1)
    {
        case '(': return false;
        case '-': return op2 == '-';
        case '+': return op2 == '-' || op2 == '+';
        case '*': return op2 != '/';
        case '/': return true;
        default : error = true; return false;
    }
}
