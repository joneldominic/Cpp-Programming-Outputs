#include <iostream>
#include <stdlib.h>
#include <vector>

using namespace std;

void display(vector <int> vectors);
int getCount(vector <int> vectors);
int getItemAt(vector <int> vectors, int index);
int findMax(vector <int> vectors);
int findMin(vector <int> vectors);
int getSum(vector <int> vectors);

int main()
{
    int numOfElement;
    int input;
    int choice;

    vector <int> vectors;

    cout<<"Enter number of elements to be accepted by the program: ";
    cin>>numOfElement;
    cout<<endl<<"Input "<<numOfElement<<" integers:"<<endl;

    if(numOfElement > 0)
    {
        for(int i=0; i<numOfElement; i++)
        {
            cin>>input;
            vectors.push_back(input);
        }

        cout<<endl;

        do{
            system("cls");
            cout<<"*********************************************"<<endl;
            cout<<"Options:"<<endl<<endl;
            cout<<"\t1 - Display elements"<<endl;
            cout<<"\t2 - Remove last element "<<endl;
            cout<<"\t3 - Remove all elements "<<endl;
            cout<<"\t4 - Count number of elements "<<endl;
            cout<<"\t5 - Display item at a specific position "<<endl;
            cout<<"\t6 - Find the Maximum element "<<endl;
            cout<<"\t7 - Find the Minimum element "<<endl;
            cout<<"\t8 - Get the sum"<<endl<<endl;
            cout<<"Input choice: ";
            cin>>choice;

            switch (choice)
            {
                case 1: cout<<endl<<"Elements in the vectors: { ";
                        display(vectors);
                        cout<<" }"<<endl<<endl;
                    break;
                case 2: vectors.pop_back();
                        cout<<endl<<"Last element removed"<<endl<<endl;
                    break;
                case 3: vectors.clear();
                        cout<<endl<<"All elements cleared"<<endl<<endl;
                    break;
                case 4: cout<<endl<<"There are "<<vectors.size()<<" elements in the vector"<<endl<<endl;
                    break;
                case 5:
                        int input;
                        cout<<endl<<"Input the index you want to access: ";
                        cin>>input;
                        if((input >= 0) && (input < getCount(vectors)))
                        {
                            cout<<endl<<"The element at index "<<input<<" in the vector is "<<getItemAt(vectors,input)<<endl<<endl;
                        }
                        else
                        {
                            cout<<endl<<"Error: Index exceeds from the number of elements in the vector"<<endl<<endl;
                        }

                    break;
                case 6: cout<<endl<<"The largest element in the vector is "<<findMax(vectors)<<endl<<endl;
                    break;
                case 7: cout<<endl<<"The largest element in the vector is "<<findMin(vectors)<<endl<<endl;
                    break;
                case 8: cout<<endl<<"The sum of all elements in the vector is "<<getSum(vectors)<<endl<<endl;
                    break;
                    default: cout<<endl<<"Error: Invalid choice"<<endl;
            }

            system("pause");
        }while(1);
    }

    else if(numOfElement <= 0)
    {
        cout<<endl<<"Error: Number of elements should not be less than or equal to zero (0)"<<endl;
    }

    return 0;
}

void display(vector <int> vectors)
{
    for(int i=0; i<getCount(vectors); i++)
    {
        cout<<vectors.at(i)<<" ";
    }
}

int getCount(vector <int> vectors)
{
    return vectors.size();
}

int getItemAt(vector <int> vectors, int index)
{
    return vectors.at(index);
}

int findMax(vector <int> vectors)
{
    int vectMax = 0;

    for (int i = 0; i < vectors.size(); i++)
    if (vectors[i] > vectMax)
    {
        vectMax = vectors[i];
    }

    return vectMax;
}

int findMin(vector <int> vectors)
{
    int vectMin = findMax(vectors);

    for (int i = 0; i < vectors.size(); i++)
    if (vectors[i] < vectMin)
    {
        vectMin = vectors[i];
    }

    return vectMin;
}

int getSum(vector <int> vectors)
{
    int sum=0;

    for(int i=0; i<getCount(vectors); i++)
    {
        sum += vectors.at(i);
    }

    return sum;
}
