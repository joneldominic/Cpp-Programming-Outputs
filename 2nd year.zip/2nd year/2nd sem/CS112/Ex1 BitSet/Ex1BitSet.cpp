//Jonel Dominic E. Tapang
#include "BitSet.h"
#include <stdio.h>

void initialize(BitSet s) {
	int i;
	for (i=0; i < MAX; i++) {
		s[i] = FALSE;
	}
}

void add(BitSet s,int x) {
	if (x >= 0 && x < MAX)
        s[x] = TRUE;
}

void display(BitSet s) {
	int i;
	printf("{");
	for (i=0; i < MAX; i++) {
		if (s[i])
			printf(" %d ",i);
	}
	printf("}");
}

//************************************

int isEmpty(BitSet s) {

    for(int i=0; i < MAX; i++)
    {
        if(s[i] == TRUE)
        {
           return 0;
        }
    }

    return 1;
}


int cardinality(BitSet s) {

    int ctr = 0;

    for(int i=0; i < MAX; i++)
    {
        if(s[i] == TRUE)
        {
            ctr++;
        }
    }

    return ctr;
}

int isEqualTo(BitSet s1,BitSet s2) {

    for(int i=0; i < MAX; i++)
    {
        if(s1[i] != s2[i])
            return 0;
    }

    return 1;
}

int isSubset(BitSet s1,BitSet s2) {

    for(int i=0; i < MAX; i++)
    {
        if(s1[i] == TRUE && s2[i] == FALSE)
            return 0;
    }

    return 1;
}

int isDisjointWith(BitSet s1,BitSet s2) {

    for(int i=0; i < MAX; i++)
    {
        if(s1[i] == TRUE && s2[i] == TRUE)
            return 0;
    }

    return 1;
}

void getUnion(BitSet s1,BitSet s2,BitSet result) {

    for(int i=0; i < MAX; i++)
    {
        if(s1[i] == TRUE || s2[i] == TRUE)
            result[i] = TRUE;
        else
            result[i] = FALSE;
    }
}

void intersection(BitSet s1,BitSet s2,BitSet result) {

    for(int i=0; i < MAX; i++)
    {
        if(s1[i] == TRUE && s2[i] == TRUE)
            result[i] = TRUE;
        else
            result[i] = FALSE;
    }
}

void difference(BitSet s1,BitSet s2,BitSet result) {

    for(int i=0; i < MAX; i++)
    {
        if(s1[i] == TRUE && s2[i] == FALSE)
            result[i] = TRUE;
        else
            result[i] = FALSE;
    }
}

void remove(BitSet s1,int x) {

    s1[x] = FALSE;
}





//Jonel Dominic E. Tapang

