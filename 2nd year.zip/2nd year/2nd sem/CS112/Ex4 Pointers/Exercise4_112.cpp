#include <iostream>

using namespace std;

void sortData(int *value);
void displayData( int *value);

int main()
{
    int *valuePtr;
    int input;

    valuePtr = new int;

    cout<<"Enter 10 integer values: "<<endl;
    for(int i=1; i<=10; i++)
    {
        cout<<endl;
        cin>>input;
        *(valuePtr+i) = input;
    }

    cout<<endl<<"Unsorted Data: ";
    displayData(valuePtr);

    sortData(valuePtr);
    cout<<endl<<endl<<"Sorted Data  : ";
    displayData(valuePtr);

    cout<<endl;

    return 0;
}

void displayData( int *dataSet)
{
    for(int i=1; i<=10; i++)
    {
        cout<<*(dataSet+i)<<" ";
    }
}

void sortData(int *value)
{
    bool SWAP = true;
    int tempHolder = 0;

    while(SWAP)
    {
        SWAP = false;

        for(int i=1; i<=9; i++)
        {
            if(*(value+i) > *(value+(i+1)))
            {
                SWAP = true;
                tempHolder = *(value+i);
                *(value+i) = *(value+(i+1));
                *(value+(i+1)) = tempHolder;
            }
        }
    }
}
