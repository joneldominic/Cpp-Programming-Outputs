#include <iostream>

using namespace std;

struct node
{
    string name;
    int age;
    float height;
    node *link;
};

node *insert(node *p, string n, int a, float h);
node *insert_beginning(node *head, string n, int a, float h);
node *insert_SpecPos(node *head, string n, int a, float h, int pos);
node *insert_end(node *temp, string n, int a, float h);
node *delete_beginning(node *head);
node *delete_SpecPos(node *head, int pos);
node *initialize(node *p, string n, int a, float h);
void header();
void printlist(node *p);
void menu();
void option(node *start, string mName, int mAge, float mHeight);

int main()
{
    node *start = NULL;
    node *list;
    string mName;
    int mAge;
    float mHeight;

    header();
    cout << "Creating initial list...\n";
    start = initialize(start, mName, mAge, mHeight);
	printlist(start);
    menu();
    option(start, mName, mAge, mHeight);

    return 0;
}

void header()
{
    cout<<"Jonel Dominic E. Tapang \t\t\t BSCS-2"<<endl;
    cout<<"This program perform some basic operations a Singly Linked List"<<endl<<endl;
}

node *insert(node *p, string n, int a, float h)
{
    if(p==NULL)
    {
		p = new node;
		p->name = n;
		p->age = a;
		p->height = h;
		p->link = NULL;
	}
	else
	{
		p->link = insert(p->link, n, a, h);
	}

	return (p);
}

node *insert_beginning(node *head, string n, int a, float h)
{
    node *newNode;

    newNode = new node;

    newNode->name = n;
    newNode->age = a;
    newNode->height = h;
    newNode->link = head;
    head = newNode;

    return (head);
}

node *insert_SpecPos(node *head, string n, int a, float h, int pos)
{
    node *dataHolder = new node;
    node *temp1 = new node;
    node *temp2 = new node;
    temp1 = head;

    dataHolder->name = n;
    dataHolder->age = a;
    dataHolder->height = h;

    if(pos==1)
    {
        head = insert_beginning(head,n,a,h);
    }
	else
    {
        for(int i=1; i<pos; i++)
        {
            temp2 = temp1;
            temp1 = temp1->link;
        }
        temp2->link = dataHolder;
        dataHolder->link = temp1;
    }

    return (head);
}

node *insert_end(node *temp, string n, int a, float h)
{
    node *temp2;   // Temporary pointers
	temp2 = temp;

	if(temp==NULL){
		temp = new node;
		temp->name = n;
		temp->age = a;
		temp->height = h;
		temp->link = NULL;
	}
	else {
		// We know this is not NULL - list not empty!
		while (temp2->link != NULL){
			temp2 = temp2->link;
		}
		temp2->link = insert(temp2->link, n, a, h);;
	}

	return (temp);
}

node *delete_beginning(node *head)
{
    node *tempNode;

    tempNode = new node;

    tempNode = head;
    head = head->link;

    delete tempNode;

    return (head);
}

node *delete_SpecPos(node *head, int pos)
{
    node *temp1 = new node;
    node *temp2 = new node;
    temp1 = head;

    if(pos==1)
    {
        head = delete_beginning(head);
    }
	else
    {
        for(int i=1; i<pos; i++)
        {
            temp2 = temp1;
            temp1 = temp1->link;
        }
        temp2->link = temp1->link;
    }

    delete temp1;

    return (head);
}

void printlist(node *p)
{
    cout<<endl;
    cout<<"***************************************************"<<endl<<endl;
    cout<< "The data values in the list are"<<endl<<endl;
	while (p!= NULL)
    {
        cout << p->name << " - " << p->age << " - " << p->height << endl;
        p = p->link;
    }
}

void menu()
{
    cout<<endl;
    cout<<"***************************************************"<<endl<<endl;
    cout<<"Insert Operations: \n";
	cout<<"\tA - Beginning of the List\n";
	cout<<"\tB - Specified position in the List\n";
	cout<<"\tC - End of the List\n";
	cout<<"Delete Operations: \n";
    cout<<"\tD - Beginning of the List\n";
	cout<<"\tE - Specified position in the List\n";
}

void option(node *start, string mName, int mAge, float mHeight)
{
    int pos;
    char opt;

    cout<<endl<<"Operation (use capital letters): ";
    cin>>opt;
    cout<<endl;

    switch (opt)
    {
        case 'A':
            cout<< "Name: ";
            cin>> mName;
            cout<< "Age: ";
            cin>> mAge;
            cout<< "Height: ";
            cin>>mHeight;
            start = insert_beginning(start, mName, mAge, mHeight);
            printlist (start);
        break;

        case 'B':
            cout<<"Position: ";
            cin>>pos;

            if( pos <= 5)
            {
                cout<< "Name: ";
                cin>> mName;
                cout<< "Age: ";
                cin>> mAge;
                cout<< "Height: ";
                cin>>mHeight;
                start = insert_SpecPos(start, mName, mAge, mHeight , pos);
                printlist (start);
            }
            else
            {
                cout<<"\nError: Invalid Position"<<endl;
            }

        break;

        case 'C':
            cout << "Name: ";
            cin >> mName;
            cout << "Age: ";
            cin >> mAge;
            cout << "Height: ";
            cin >>mHeight;
            start = insert_end(start, mName, mAge, mHeight);
            printlist (start);
        break;

        case 'D':
            start = delete_beginning(start);
            printlist(start);
        break;

        case 'E':
            cout<<"Position: ";
            cin>>pos;

            if( pos <= 5)
            {
                start = delete_SpecPos(start, pos);
                printlist(start);
            }
            else
            {
                cout<<"\nError: Invalid Position"<<endl;
            }
        break;

        default: cout<<"Error: Operation should be within (A-E)"<<endl;
    }
}

node *initialize(node *p, string n, int a, float h)
{
    for (int i=1; i<=5; i++)
    {
        cout<<endl;
		cout << "Name: ";
		cin >> n;
		cout << "Age: ";
		cin >> a;
		cout << "Height: ";
		cin >> h;
		p = insert ( p, n, a, h);
	}

	return p;
}
