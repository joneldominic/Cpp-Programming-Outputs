#include <iostream>
#include <vector>

using namespace std;

void BinaryEquiv(long int x);
void OctEquiv(long int x);
void HexEquiv(long int x);

int main()
{
    long int decimal;
    int choice;

    cout<<"Enter a positive decimal: ";
    cin>>decimal;
    cout<<endl;

    if(decimal >= 0)
    {
        cout<<"\t1. Binary"<<endl;
        cout<<"\t2. Octal"<<endl;
        cout<<"\t3. Hexadecimal"<<endl<<endl;
        cout<<"Convert to (Please select one): ";
        cin>>choice;

        switch (choice)
        {
            case 1: BinaryEquiv(decimal);
                break;
            case 2: OctEquiv(decimal);
                break;
            case 3: HexEquiv(decimal);
                break;

            default: cout<<endl<<"Error: Invalid choice"<<endl;
        }
    }
    else
    {
        cout<<"Error: Input should be a positive integer"<<endl;
    }

    return 0;
}

void BinaryEquiv(long int x)
{
    vector <int> binary;

    while(x!=0)
    {
        binary.push_back(x%2);
        x/=2;
    }

    cout<<endl<<"Binary equivalent = ";

    for(int i = (binary.size()-1) ; i >= 0 ; i--)
    {
        cout<<binary[i];
    }
}

void OctEquiv(long int x)
{
     vector <int> octal;

    while(x!=0)
    {
        octal.push_back(x%8);
        x/=8;
    }

    cout<<endl<<"Binary equivalent = ";

    for(int i = (octal.size()-1) ; i >= 0 ; i--)
    {
        cout<<octal[i];
    }
}

void HexEquiv(long int x)
{
    vector <int> hex;

    while(x!=0)
    {
        hex.push_back(x%16);
        x/=16;
    }

    cout<<endl<<"Binary equivalent = ";

    for(int i = (hex.size()-1) ; i >= 0 ; i--)
    {
        switch (hex[i])
        {
            case 10: cout<<'A';
                break;
            case 11: cout<<'B';
                break;
            case 12: cout<<'C';
                break;
            case 13: cout<<'D';
                break;
            case 14: cout<<'E';
                break;
            case 15: cout<<'F';
                break;

            default: cout<<hex[i];
        }
    }
}
