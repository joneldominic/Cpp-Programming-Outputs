#include <iostream>
#include <cmath>
using namespace std;

int main()
    {
        float v=0, h=0, r=0, pi=3.1416, c=0;
        cout<<"Input volume: ";
        cin>>v;
        cout<<endl;
        cout<<"Input height: ";
        cin>>h;
        cout<<endl;
        r= sqrt (((pi*h)/v));
        c=2*pi*r;
        cout<<"Circumference: "<<c<<endl;

        return 0;
    }
