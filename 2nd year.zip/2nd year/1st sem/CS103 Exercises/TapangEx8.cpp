#include <iostream>
#include <cstdlib>

using namespace std;

struct student
{
    int IDNum;
    string studentName;
    char course[5];
};

void dispStudentRec(student studentRec[], int SIZE);
void sortByIDNumAsc(student studentRec[], int SIZE);
void searchStudentName(student studentRec[], int SIZE, string searchItem);

int main()
{
    string searchItem;
    char operation,choice;

    student studentRec[5] = {{54651, "Jonel", "BSCS"},
                             {65413, "Roy", "BSCE"},
                             {34518, "Jim", "BSME"},
                             {21645, "Steph", "BSEd"},
                             {14654, "Jay", "BSA"}};

    do{
        system("cls");
        cout<<"Simple Record Management"<<endl<<endl;
        cout<<"\t[1] Display Contents"<<endl;
        cout<<"\t[2] Sort by ID number"<<endl;
        cout<<"\t[3] Search by student name"<<endl<<endl;
        cout<<"Select operation: ";
        cin>>operation;

        switch(operation)
        {
        case '1':
                dispStudentRec(studentRec,5);
            break;

        case '2':
                sortByIDNumAsc(studentRec,5);
            break;

        case '3':
                cout<<endl<<"Search Name: ";
                cin>>searchItem;
                searchStudentName(studentRec,5,searchItem);
            break;

        default: cout<<endl<<"*** Invalid Operation"<<endl;
        }

        cout<<endl<<"Do you want to exit? [y]/[n]: ";
        cin>>choice;
        cout<<endl;

    }while(choice=='n' || choice=='N');

    return 0;
}

void dispStudentRec(student studentRec[], int SIZE)
{
    cout<<endl;
    cout<<"IDNum \t Student Name \t Course"<<endl;
    cout<<"-------------------------------"<<endl;

    for(int i=0;i<SIZE;i++)
    {
        cout<<studentRec[i].IDNum<<" \t "<<studentRec[i].studentName<<" \t\t "<<studentRec[i].course<<endl;
    }
}

void sortByIDNumAsc(student studentRec[], int SIZE)
{
    bool SWAP = true;
    student tempHolder;

    while(SWAP)
    {
        SWAP = false;
        SIZE--;

        for(int i=0;i<SIZE;i++)
        {
            if(studentRec[i].IDNum>studentRec[i+1].IDNum)
            {
                SWAP = true;

                tempHolder = studentRec[i];
                studentRec[i] = studentRec[i+1];
                studentRec[i+1] = tempHolder;
            }
        }
    }

    cout<<endl<<"Records are sorted!"<<endl;
}

void searchStudentName(student studentRec[], int SIZE, string searchItem)
{
    bool found = false;

    cout<<endl;
    cout<<"IDNum \t Student Name \t Course"<<endl;
    cout<<"-------------------------------"<<endl;

    for(int i=0;i<SIZE;i++)
    {
        if(searchItem==studentRec[i].studentName)
        {
            cout<<studentRec[i].IDNum<<" \t "<<studentRec[i].studentName<<" \t\t "<<studentRec[i].course<<endl;

            found = true;
        }
    }
    if(!found)
    {
        cout<<endl<<"*** Search item is does not exist."<<endl;
    }
}
