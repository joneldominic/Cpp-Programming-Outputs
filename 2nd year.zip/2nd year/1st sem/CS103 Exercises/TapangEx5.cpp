#include <iostream>

using namespace std;

bool isEven(int x);
bool isPrime(int x);
void printGoldbachPair(int x);

int main()
{
    printGoldbachPair(10);

    return 0;
}

bool isEven(int x)
{
    if(x%2==0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool isPrime(int x)
{
    int ctr=0;

    for(int i=2;i<=x;i++)
    {
        if(x%i==0)
        {
            ctr++;
        }
    }
    if(ctr==1)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void printGoldbachPair(int input)
{
    bool flag=true;
    int num1, num2;

    //cout<<"Input an even positive integer greater than four(4): ";
    //cin>>input;

    if(isEven(input) && input>4)
    {
        num1=input/2;
        num2=input/2;

        cout<<input<<" = ";

        while(flag)
        {
            if(isPrime(num1) && isPrime(num2))
            {
                cout<<num1<<" + "<<num2;
                flag=false;
            }
            num1++;
            num2--;
        }
    }
    else
    {
        cout<<"Error: Input should be an even positive integer greater than four (4)."<<endl;
    }
}
