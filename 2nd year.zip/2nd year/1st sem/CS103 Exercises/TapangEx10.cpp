#include <iostream>

using namespace std;

class cylinderTank
{
    private:
        double height;
        double radius;
        double aveDrainRate;
        double aveFillRate;

    public:
        cylinderTank();
        void setHeight(double);
        void setRadius(double);
        void setDrainRate(double);
        void setFillRate(double);
        double getHeight();
        double getRadius();
        double getDrainRate();
        double getFillRate();
        double volume();
        void timeToFillEmpty();
        void timeToFillPartial(double partial);
        ~cylinderTank();
};

int main()
{
    cylinderTank Tank;
    Tank.setHeight(10);
    Tank.setRadius(3);
    Tank.setDrainRate(24);
    Tank.setFillRate(43);
    cout<<"Height: "<<Tank.getHeight()<<endl;
    cout<<"Radius: "<<Tank.getRadius()<<endl;
    cout<<"Drain rate: "<<Tank.getDrainRate()<<" liters/sec"<<endl;
    cout<<"Fill rate: "<<Tank.getFillRate()<<" liters/sec"<<endl;
    cout<<"Volume: "<<Tank.volume()<<endl;
    Tank.timeToFillEmpty();
    Tank.timeToFillPartial(153342);

    return 0;
}

cylinderTank::cylinderTank()
{
    height = 0;
    radius = 0;
    aveDrainRate = 0;
    aveFillRate = 0;
}

void cylinderTank::setHeight(double H)
{
    height = H;
}

void cylinderTank::setRadius(double R)
{
    radius = R;
}

void cylinderTank::setDrainRate(double dR)
{
    aveDrainRate = dR;
}

void cylinderTank::setFillRate(double fR)
{
    aveFillRate = fR;
}

double cylinderTank::getHeight()
{
    return height;
}

double cylinderTank::getRadius()
{
    return radius;
}

double cylinderTank::getDrainRate()
{
    return aveDrainRate;
}

double cylinderTank::getFillRate()
{
    return aveFillRate;
}

double cylinderTank::volume()
{
    const double PI = 3.1416;
    double v;

    v = (PI * (radius * radius) * height);

    return v;
}

void cylinderTank::timeToFillEmpty()
{
    double vol = volume();
    double volInLiters;
    int hr, mins, sec, totalVol;

    if(aveFillRate > aveDrainRate)
    {
        volInLiters = vol * 1000;

        totalVol= (volInLiters * (aveFillRate-aveDrainRate));

        hr = (totalVol/3600)/60;
        mins =(totalVol % 3600)/60;
        sec = (totalVol/3600)%60;


        cout<<"Time to fill when empty: "<<hr<<":"<<mins<<":"<<sec<<endl;

    }
    else
    {
        cout<<"Error: Drain rate is much greater than fill rate"<<endl;
    }

}

void cylinderTank::timeToFillPartial(double partial)
{
    double vol = volume();
    double volInLiters;
    int hr, mins, sec, totalVol;

    if(aveFillRate > aveDrainRate)
    {
        volInLiters = vol * 1000;

        if(volInLiters > partial)
        {
            volInLiters = volInLiters - partial;

            totalVol = (volInLiters * (aveFillRate-aveDrainRate));

            hr = (totalVol/3600)/60;
            mins =(totalVol % 3600)/60;
            sec = (totalVol/3600)%60;

            cout<<"Time to fill when partially filled with "<<partial<<" liters: "<<hr<<":"<<mins<<":"<<sec<<endl;
        }
        else
        {
            cout<<"Error: Partial content is greater than the volume of the cylinder"<<endl;
        }


    }
     else
    {
        cout<<"Error: Drain rate is much greater than fill rate"<<endl;
    }


}

cylinderTank::~cylinderTank()
{

}

