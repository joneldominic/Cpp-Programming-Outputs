//Jonel Dominic E. Tapang
#include <iostream>

using namespace std;

void matrixMultiply(int A[][4], int B[][4], int C[][4]);
void dispMatrices(int A[][4], int B[][4], int C[][4]);

int main()
{
	int matrixA[3][4] = {{2,3,1,2}, {5,4,3,4}, {6,2,5,1}};
	int matrixB[4][4] = {{2,1,5,2}, {4,2,5,3}, {4,1,3,2}, {5,2,6,4}};
	int matrixC[3][4];

    matrixMultiply(matrixA, matrixB, matrixC);
    dispMatrices(matrixA, matrixB, matrixC);

	return 0;
}


void matrixMultiply(int A[][4], int B[][4], int C[][4])
{
    //Initialize elements of matrixC to 0.
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<4;j++)
		{
			C[i][j] = 0;
		}
	}

	for(int i=0;i<3;i++)
	{
		for(int j=0;j<4;j++)
		{
			for(int k=0;k<4;k++)
			{
				C[i][j] += A[i][k] * B[k][j];
			}
		}
	}
}

void dispMatrices(int A[][4], int B[][4], int C[][4])
{
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<4;j++)
		{
			cout<<C[i][j]<<" ";

			if(j==3)
				cout<<endl<<endl;
		}
	}
}
