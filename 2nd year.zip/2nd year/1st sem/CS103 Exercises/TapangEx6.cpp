#include <iostream>
#include <cstdlib>
using namespace std;

void randInitArray(int x[], int s);
void dispArrayContents(int x[], int s);
bool isFib(int x);
int arrayFibCtr(int x[], int s);

int main()
{
    int x[15];

    randInitArray(x,15);
    dispArrayContents(x,15);
    cout<<endl<<"Total Fibonicci numbers: "<<arrayFibCtr(x,15);

    return 0;
}

void randInitArray(int x[], int s)
{
    for(int ctr=0;ctr<s;ctr++)
    {
        x[ctr]= rand()%15;
    }
}

void dispArrayContents(int x[], int s)
{
    for(int ctr=0;ctr<s;ctr++)
    {
        cout<<x[ctr]<<" , ";
    }
}

bool isFib(int x)
{
    int f1=0,f2=1,f;
    while(f2<x)
    {
        f=f1+f2;
        f1=f2;
        f2=f;
    }
    if(f2==x)
        return true;
    else
        return false;
}

int arrayFibCtr(int x[], int s)
{
    int fibctr=0;

    for(int ctr=0;ctr<s;ctr++)
    {
        if(isFib(x[ctr]))
            fibctr++;
    }
    return fibctr;
}
