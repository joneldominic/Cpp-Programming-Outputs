#include <iostream>
using namespace std;

void exercise4()
{
    int num1, num2, numx, ctr=0;
    cin>>num1;
    cout<<"to"<<endl;
    cin>>num2;
    cout<<endl;

    while (num1<=num2)
    {
        numx=num1;
        while (numx!=1)
        {
            if (numx%2==0)
            {
                numx=numx/2;
            }
            else
            {
                numx=numx*3+1;
            }
            cout<<numx<<",";
            ctr++;
        }
        cout<<endl;
        num1++;
    }
    cout<<"\n***************************************"<<endl;
    cout<<"Numer of cycles: "<<ctr<<endl<<endl;
}

int main()
{
    exercise4();
    return 0;
}
