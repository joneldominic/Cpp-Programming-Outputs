#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

struct student
{
    string studentName;
    double score;
};

void readFromRecord (student studScoreRec[]);
double recAverage (student studScoreRec[], int s);
double recSTDev (student studScoreRec[], int s, double ave);
void writeResultToFile (double ave, double stDev);

int main()
{
    double average = 0;
    double STDev = 0;

    student studentArr[7];

    readFromRecord(studentArr);
    average = recAverage(studentArr,7);
    STDev = recSTDev(studentArr,7,average);
    writeResultToFile (average, STDev);

    return 0;
}

void readFromRecord (student studScoreRec[])
{
    int i=0;

    ifstream inStudRecFile;
    inStudRecFile.open("StudentScore.txt",ios::in);

    if(inStudRecFile.is_open())
    {
        while(!inStudRecFile.eof())
        {
            getline(inStudRecFile,studScoreRec[i].studentName,'\t');
            inStudRecFile>>studScoreRec[i].score;
            inStudRecFile.ignore();

            i++;
        }
        inStudRecFile.close();
    }
}

double recAverage (student studScoreRec[], int s)
{
    double acc = 0;
    double average = 0;

    for(int i=0;i<s;i++)
    {
        acc += studScoreRec[i].score;
    }

    average = acc/s;

    return average;
}

double recSTDev(student studScoreRec[], int s, double ave)
{
    double acc=0;
    double variance = 0;
    double STDev = 0;

    for(int i=0;i<s;i++)
    {
        acc += pow((studScoreRec[i].score - ave),2);
    }

    variance = acc/s;
    STDev = sqrt(variance);

    return STDev;
}

void writeResultToFile (double ave, double stDev)
{
    ofstream outStudRecFile;
    outStudRecFile.open("scoreDesc.txt",ios::out);

    if(outStudRecFile.is_open())
    {
        outStudRecFile<<"Average: "<<ave<<endl;
        outStudRecFile<<"Standard Deviation: "<<stDev<<endl;

        outStudRecFile.close();
    }
}
