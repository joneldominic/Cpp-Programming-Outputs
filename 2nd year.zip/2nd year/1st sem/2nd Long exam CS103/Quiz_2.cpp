#include <iostream>
using namespace std;

void code_analysis_I()
{
    int x=5, y=12, acc=0;
    while(x<=y)
    {
        if(x%3==0)
        {
            acc+=x;
        }
        x++;
    }
    cout<<acc;
}

void code_analysis_II()
{
    int x=5, y=11, pow=3, var, ctr=0;
    for (x;x<=y;x++)
    {
        ctr=0, var=1;
        while(ctr<pow)
        {
            var*=x;
            ctr++;
        }
        cout<<var<<",";
    }
}

void program_tracing_I()
{
    /*
    this code snippets adds the value of x two times
    plus 1 and increments the value pf x until x is not
    less than to y

    output: 9,13,17
    */
    int x=4, y=9;

    if((x-y)%2!=0)
    {
        while(x<y)
        {
            cout<<x+x+1<<",";
            x+=2;
        }
    }
}

void program_tracing_II()
{
    /*
    this code snippet do division using repeated subtraction
    output: 8 1
    */
    int x=3, y=25,ctr=0;

    while(y>=x)
    {
        y-=x;
        ctr++;
    }
    cout<<ctr <<" "<<y;
}

void programming_on_paper()
{
    int x=8, y=10;
    double km=0;
    cout<<"Start range: "<<x<<endl;
    cout<<"End range: "<<y<<endl<<endl;

    if(x>0 && y>0)
    {
        cout<<"Mile(s)\t\tKilometer(s)"<<endl;
        while(x<=y)
        {
            km=x*1.61;
            cout<<x<<"\t\t"<<km<<endl;
            x++;
        }
    }
}

int main()
{
    //code_analysis_I();
    //code_analysis_II();
    //program_tracing_I();
    //program_tracing_II();
    programming_on_paper();

}
