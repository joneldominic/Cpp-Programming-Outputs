#ifndef BANKACCOUNT_H_INCLUDED
#define BANKACCOUNT_H_INCLUDED

class bankAccount
{
    public:
        bankAccount();

        void print();
        void setAccoutNum(int);
        void depositMoney(double);
        void withDrawMoney(double);
        int getAccountNum();
        double getBalance();

        ~bankAccount();


    private:
        int accountNum;
        double balance;
};

#endif // BANKACCOUNT_H_INCLUDED
