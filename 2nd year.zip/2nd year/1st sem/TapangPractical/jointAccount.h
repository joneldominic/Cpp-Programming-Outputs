#include "savingsAccount.h"
#ifndef JOINTACCOUNT_H_INCLUDED
#define JOINTACCOUNT_H_INCLUDED

class jointAccount: public savingsAccount
{
    public:
        jointAccount();
        void print();
        void setHolderA(int, double);
        void setHolderB(int, double);
        void setJointBal();
        double getJointBal();
        void withDrawMoney(double, int, int);
        void depositMoney(double);
        savingsAccount getHolderA();
        savingsAccount getHolderB();

        ~jointAccount();

    private:
        savingsAccount holderA;
        savingsAccount holderB;
        double jointBal;
};

#endif // JOINTACCOUNT_H_INCLUDED
