#include "jointAccount.h"
#include <iostream>
#include <fstream>

using namespace std;

void writeToFile(savingsAccount SA[],int SIZE);

int main()
{
    savingsAccount Account[5];

    for(int i=0;i<5;i++)
    {
        Account[i].setAccoutNum(i+12);
        Account[i].depositMoney(((i+1)*500));
        Account[i].setInterRate(10);
    }

    writeToFile(Account,5);
}

void writeToFile(savingsAccount rec[],int SIZE)
{
    ofstream outRecord;

    outRecord.open("Bank Records.txt", ios::out);
    if(outRecord.is_open())
    {
        for(int i=0;i<SIZE;i++)
        {
            outRecord<<"Account Number: "<<rec[i].getAccountNum()<<endl;
            outRecord<<"Balance: "<<rec[i].getBalance()<<endl;
            outRecord<<"Post Interest (10%): "<<rec[i].getPostInterest()<<endl<<endl;
        }

        outRecord.close();
    }
}

