#include "bankAccount.h"
#include <iostream>

using namespace std;

bankAccount::bankAccount()
{
    accountNum = 0;
    balance = 0;
}

void bankAccount::print()
{
    if(balance > 0)
    {
        cout<<"Account Number: "<<getAccountNum()<<endl;
        cout<<"Balance: "<<getBalance()<<endl;
    }
    else
    {
        cout<<"Account Number: "<<accountNum<<endl;
        cout<<"**Transaction cannot be process"<<endl;
    }

}

void bankAccount::setAccoutNum(int accNum)
{
    accountNum = accNum;
}

int bankAccount::getAccountNum()
{
    return accountNum;
}

double bankAccount::getBalance()
{
    return balance;
}

void bankAccount::depositMoney(double depMon)
{
    if(depMon > 0)
    {
        balance += depMon;
    }
}

void bankAccount::withDrawMoney(double wdMon)
{
    if(wdMon > 0)
    {
        balance -= wdMon;
    }
}


bankAccount::~bankAccount()
{

}
