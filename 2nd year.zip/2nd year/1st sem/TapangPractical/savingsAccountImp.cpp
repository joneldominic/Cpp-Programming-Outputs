#include "savingsAccount.h"
#include <iostream>

using namespace std;

savingsAccount::savingsAccount()
{
    interRate = 0;
    postInter = 0;
}

void savingsAccount::setInterRate(double intRate)
{
    if(intRate > 0)
    {
         interRate = intRate;
    }
}

double savingsAccount::getInterRate()
{
    return interRate;
}

double savingsAccount::getPostInterest()
{
    double bal;

    bal = getBalance();
    postInter = (bal * interRate) / 100;

    return postInter;
}


void savingsAccount::withDrawMoney(double wdMon)
{
    double bal, postInt;

    bal = getBalance();
    postInt = getPostInterest();

    bal  = (bal+postInt) - wdMon;
}


void savingsAccount::print()
{
    bankAccount::print();
    cout<<"Post Interest: "<<getPostInterest()<<endl;

}

savingsAccount::~savingsAccount()
{

}
