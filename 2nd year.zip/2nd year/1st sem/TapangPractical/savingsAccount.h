#include "bankAccount.h"
#ifndef SAVINGSACCOUNT_H_INCLUDED
#define SAVINGSACCOUNT_H_INCLUDED

class savingsAccount: public bankAccount
{
    public:
        savingsAccount();
        void print();
        void setInterRate(double);
        void withDrawMoney(double);
        double getInterRate();
        double getPostInterest();

        ~savingsAccount();

    private:
        double interRate;
        double postInter;
};

#endif // SAVINGSACCOUNT_H_INCLUDED
