#include "jointAccount.h"
#include <iostream>

using namespace std;

jointAccount::jointAccount()
{
    holderA.setAccoutNum(0);
    holderA.depositMoney(0);
    holderB.setAccoutNum(0);
    holderB.depositMoney(0);
}
void jointAccount::print()
{
    cout<<"Joint Account of "<<holderA.getAccountNum()<<" and "<<holderB.getAccountNum()<<endl;
    cout<<"Balance: "<<jointBal<<endl;
}

void jointAccount::setJointBal()
{
    double balA, balB;

    balA = holderA.getBalance();
    balB = holderB.getBalance();

    jointBal = balA + balB;
}

void jointAccount::setHolderA(int accNum, double dipo)
 {
    holderA.setAccoutNum(accNum);
    holderA.depositMoney(dipo);
 }

void jointAccount::setHolderB(int accNum, double dipo)
{
    holderB.setAccoutNum(accNum);
    holderB.depositMoney(dipo);
}

void jointAccount::withDrawMoney(double wdMon, int hA, int hB)
{
    int h1 = holderA.getAccountNum();
    int h2 = holderB.getAccountNum();

     if((h1 == hA) && (h2 == hB) && (wdMon > 0))
     {
        jointBal -= wdMon;
     }
     else
     {
         cout<<"*Withdrawal transaction denied"<<endl;
     }
}

void jointAccount::depositMoney(double depoAm)
{
    jointBal += depoAm;
}

savingsAccount jointAccount::getHolderA()
{
    return holderA;
}

savingsAccount jointAccount::getHolderB()
{
    return holderB;
}

double jointAccount::getJointBal()
{
    return jointBal;
}

 jointAccount::~jointAccount()
 {

 }

