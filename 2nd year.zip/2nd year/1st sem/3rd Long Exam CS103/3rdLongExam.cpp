#include <iostream>
#include <cmath>

using namespace std;

int digitCtr(int x);
int isTriangleNumber(int x);
int tssRecursive(int n);
int hMpS(int x, int y);

int main()
{
    //cout<<digitCtr(150);
    //cout<<isTriangleNumber(6);
    //cout<<tssRecursive(4);
    cout<<hMpS(3,17);


    return 0;
}

/*
This code would count (then return) the number of digits
from formal parameter x
*/

int digitCtr(int x)
{
    int ctr=0;

    while (x!=0)
    {
        x/=10;
        ctr++;
    }
    return ctr;
}

/*
The infinite series whose terms are the natural numbers 1 + 2 + 3 + 4 + n is divergent
series, the nth partial sum is the triangle number. This function would check if the formal
parameter x is a triangle number.
*/

int isTriangleNumber(int x)
{
    int series = 1, accumulator = 0;
    while(accumulator < x)
    {
        accumulator+=series;
        series++;
    }
    if (accumulator==x)
        return true;
    else
        return false;
}

/*
This code will get the product of n square plus the product
 of n square plus n-1 while n is not equal to zero.
*/

int tssRecursive(int n) //Total Sum of Squares
{
    if (n==0)
    {
        return 0;
    }
    else
    {
        return n*n + tssRecursive(n-1);
    }
}

/*
This code will get the total number of perfect square ranging from x to y-1
*/

int hMpS(int x, int y) //How Many Perfect Square
{
    int square = 0, ctr = 0;
    while (x<y)
    {
        square=static_cast<int>(sqrt(x));
        if(square*square == x)
            ctr++;
        x++;
    }
    return ctr;
}
