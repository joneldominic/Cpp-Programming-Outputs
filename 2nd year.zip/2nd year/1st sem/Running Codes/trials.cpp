#include <iostream>

using namespace std;

bool isEven(int x);
bool isPrime(int x);
void printGoldbachPair(int x);

int main()
{
    int x;
    printGoldbachPair(x);
    return 0;
}


bool isEven(int x)
{
    if(x%2==0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool isPrime(int x)
{
    int ctr=0;

    for(int i=2;i<=x;i++)
    {
        if(x%i==0)
        {
            ctr++;
        }
    }
    if(ctr==1)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void printGoldbachPair(int x)
{
    int num1,num2;
    cout<<"Input an even positive integer greater than four (4): ";
    cin>>x;

    if(isEven(x) && x>4)
    {
        num1=x/2;
        num2=x/2;

        cout<<x<<" = ";

        while(num2<=x)
        {
            if(isPrime(num1) && isPrime(num2))
            {
                cout<<num1<<" + "<<num2<<", ";
            }
            num1--;
            num2++;
        }
    }
    else
    {
        cout<<"Error: Input should be an even positive integer greater than four (4).";
    }
}
