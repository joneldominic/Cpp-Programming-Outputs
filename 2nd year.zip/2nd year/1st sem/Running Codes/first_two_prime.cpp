#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int n, i, j, k, l;
    char prime, prime1;
    do   //check if n is even and greater than 2
    {
        cout<<"Give me an even natural number greater than 2:\n\n>";
        cin>>n;
    }
    while (n % 2 != 0 && n >= 2);
    for (i=1 ;i<n ;i++)
    {
        prime = 1;
        for (k=2 ;k<i ;k++)
            if (i % k == 0)
                prime = 0;
        if (prime)
        {
            for (j=1; j<n; j++)
            {
                prime1 = 1;
                for (l=2; l<j; l++)
                    if(j % l == 0)
                        prime1 = 0;
                if (prime1)
                    if (i + j == n)
                    {
                        cout<<i<<" and "<<j<<" are the first two prime numbers that add up to "<<n;
                        return 0;
                    }
            }
        }
    }
}
