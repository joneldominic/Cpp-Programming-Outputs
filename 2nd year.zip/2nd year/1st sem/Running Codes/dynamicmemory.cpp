#include <iostream>

using namespace std;

int main()
{
    int input, temp;
    int *pointer = NULL;
    cout<<"How many items you are gonna enter: ";
    cin>>input;

    pointer = new int[input];

    for(int i=0;i<input;i++)
    {
        cout<<"Enter a number for element "<<i+1<<": ";
        cin>>temp;
        *(pointer+i) = temp;
    }

    cout<<"\nThe numbers you have inputted are:"<<endl;

    for(int j=0;j<input;j++)
    {
        cout<<*(pointer+j)<<endl;
    }

    delete []pointer;



    return 0;
}


