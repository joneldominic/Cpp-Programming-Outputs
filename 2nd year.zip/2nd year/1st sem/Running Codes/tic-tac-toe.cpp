#include <iostream>
#include <stdlib.h>
using namespace std;

char _move,board_in_game;
string player_1,player_2;
int move_counter;
int main();
 char board [3][3] = {
                            {'1','2','3'},
                            {'4','5','6'},
                            {'7','8','9'}
                        };
void defaultBoard()
{
    char board [3][3] = {
                            {'1','2','3'},
                            {'4','5','6'},
                            {'7','8','9'}
                        };

    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2];

}


void board_new_game()
{
    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2];
}

char move_player1(char _move)
{
    cout<<"\n\n"<<player_1<<", your turn. (X)"<<endl;
    cout<<"Choose a position in the board: ";
    cin>>_move;
    cout<<endl;
    system("cls");

    switch(_move)
    {
        case '1':
            if (board[0][0]=='X' || board[0][0]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player1(_move);

                }
            else
                {
                    board[0][0]='X';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }
        break;
        case '2':
            if (board[0][1]=='X' || board[0][1]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player1(_move);

                }
            else
                {
                    board[0][1]='X';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }

        break;
        case '3':
            if (board[0][2]=='X' || board[0][2]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player1(_move);

                }
            else
                {
                    board[0][2]='X';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }


        break;
        case '4':
            if (board[1][0]=='X' || board[1][0]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player1(_move);
                }
            else
                {
                    board[1][0]='X';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }
        break;
        case '5':
            if (board[1][1]=='X' || board[1][1]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player1(_move);

                }
            else
                {
                    board[1][1]='X';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }

        break;
        case '6':
            if (board[1][2]=='X' || board[1][2]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player1(_move);

                }
            else
                {
                    board[1][2]='X';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }
        break;
        case '7':
            if (board[2][0]=='X' || board[2][0]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player1(_move);

                }
            else
                {
                    board[2][0]='X';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }

        break;
        case '8':
            if (board[2][1]=='X' || board[2][1]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player1(_move);

                }
            else
                {
                    board[2][1]='X';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }

        break;
        case '9':
            if (board[2][2]=='X' || board[2][2]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player1(_move);

                }
            else
                {
                    board[2][2]='X';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }

        break;
        default:
            cout<<"Error: Invalid position. Please choose a position from 1-9. "<<endl<<endl;
            board_new_game();
            move_player1(_move);
    }
}

char move_player2(char _move)
{
    cout<<"\n\n"<<player_2<<", your turn. (O)"<<endl;
    cout<<"Choose a position in the board: ";
    cin>>_move;
    cout<<endl;
    system("cls");

    switch(_move)
    {
        case '1':
            if (board[0][0]=='X' || board[0][0]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player2(_move);

                }
            else
                {
                    board[0][0]='O';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }

        break;
        case '2':
            if (board[0][1]=='X' || board[0][1]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player2(_move);
                }
                else
                {
                    board[0][1]='O';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }

        break;
        case '3':
            if (board[0][2]=='X' || board[0][2]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player2(_move);

                }
            else
                {
                    board[0][2]='O';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }

        break;
        case '4':
            if (board[1][0]=='X' || board[1][0]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player2(_move);

                }
            else
                {
                    board[1][0]='O';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }
        break;
        case '5':
            if (board[1][1]=='X' || board[1][1]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player2(_move);

                }
            else
               {
                    board[1][1]='O';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
               }
        break;
        case '6':
            if (board[1][2]=='X' || board[1][2]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player2(_move);
                }
            else
                {
                    board[1][2]='O';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }
        break;
        case '7':
            if (board[2][0]=='X' || board[2][0]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player2(_move);

                }
            else
                {
                    board[2][0]='O';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }
        break;
        case '8':
            if (board[2][1]=='X' || board[2][1]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player2(_move);

                }
            else
                {
                    board[2][1]='O';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
                }
        break;
        case '9':
            if (board[2][2]=='X' || board[2][2]=='O')
                {
                    cout<<"Error: Invalid position. Please choose a position an 'X' or 'O'"<<endl<<endl<<endl;
                    board_new_game();
                    move_player2(_move);

                }
                    board[2][2]='O';
                    move_counter++;
                    cout<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<endl;
                    cout<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<endl;
                    cout<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<endl;
        break;

        default:
            cout<<"Error: Invalid position. Please choose a position from 1 - 9"<<endl<<endl;
            board_new_game();
            move_player2(_move);
    }
}

void checker_player1()
{
    if ((board[0][0]=='X' && board[0][1]=='X' && board[0][2]=='X') || (board[0][0]=='X' && board[1][1]=='X' && board[2][2]=='X') ||
        (board[2][0]=='X' && board[1][1]=='X' && board[0][2]=='X') || (board[2][0]=='X' && board[2][1]=='X' && board[2][2]=='X') ||
        (board[0][0]=='X' && board[1][0]=='X' && board[2][0]=='X') || (board[0][2]=='X' && board[1][2]=='X' && board[2][2]=='X') ||
        (board[0][1]=='X' && board[1][1]=='X' && board[2][1]=='X') || (board[1][0]=='X' && board[1][1]=='X' && board[1][2]=='X'))
   {
        cout<<endl<<player_1<<" wins!"<<endl<<endl;
        system("pause");
        exit(main());

   }
}

void checker_player2()
{
    if ((board[0][0]=='O' && board[0][1]=='O' && board[0][2]=='O') || (board[0][0]=='O' && board[1][1]=='O' && board[2][2]=='O') ||
        (board[2][0]=='O' && board[1][1]=='O' && board[0][2]=='O') || (board[2][0]=='O' && board[2][1]=='O' && board[2][2]=='O') ||
        (board[0][0]=='O' && board[1][0]=='O' && board[2][0]=='O') || (board[0][2]=='O' && board[1][2]=='O' && board[2][2]=='O') ||
        (board[0][1]=='O' && board[1][1]=='O' && board[2][1]=='O') || (board[1][0]=='O' && board[1][1]=='O' && board[1][2]=='O'))
   {
        cout<<endl<<player_2<<" wins!"<<endl<<endl;
        system("pause");
        exit(main());

   }


}

void draw_checker()
{
    if(move_counter==9)
    {
        cout<<endl<<"The game was a draw!"<<endl<<endl;
        system("pause");
        exit(main());

    }
}
int main()
{
    bool status;

    system( "cls");
    cout<<"This is a tic-tac-toe game. This game requires two players."<<endl;
    cout<<"Player 1 will be marked by 'X' and Player 2 will be marked by 'O'."<<endl;
    cout<<"Whoever can first create a 3-X line or 3-O line wins."<<endl<<endl;
    cout<<"Enter a name for player 1: ";
    cin>>player_1;
    cout<<endl<<"Enter a name for player 2: ";
    cin>>player_2;
    cout<<endl<<endl;
    system("cls");

    defaultBoard();


    while(status==0)
    {
        move_player1(_move);
        checker_player1();
        draw_checker();

        move_player2(_move);
        checker_player2();
        draw_checker();
    }
    return 0;
}


