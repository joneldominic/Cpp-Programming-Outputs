#include <iostream>
#include <stdlib.h>
using namespace std;


int main()
    {
        int num, i, countFactors, desired_num;
        int countBreak = 0;
        cout<<"Enter a positive integer: ";
        cin>>desired_num;
        cout<<"********************************"<<endl;
        cout<< "Prime numbers of 1-"<<desired_num<<":"<<endl;

        for (num=1;num<=desired_num;num++)
        {
            countFactors=0;

            for (i=2;i<=num;i++)
            {
                if (num % i == 0)
                {
                    countFactors++;
                }
            }

            if (countFactors == 1)
            {
                cout << num << "  ";
                countBreak++;

                if(countBreak == 8)
                {
                    cout<<endl;
                    countBreak = 0;
                }
            }
        }
 system("pause");
 return 0;
}
