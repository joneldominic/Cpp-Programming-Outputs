#include <iostream>>
using namespace std;

void hello_world();
void size_of_datatypes();
void variable_declaration();
void define_proprocessor();
void sign_unsigned_int();
//wala pa page 22

int main()
{
    //hello_world();
    //size_of_datatypes();
    //variable_declaration();
    //define_proprocessor();
    //sign_unsigned_int();
    return 0;
}

void hello_world()
{
    cout<<"Hello World"; //prints Hello World
}

void size_of_datatypes()
{
    cout<<"Size of char: "<<sizeof(char)<<endl;
    cout<<"Size of int: "<<sizeof(int)<<endl;
    cout<<"Size of short int: "<<sizeof(short int)<<endl;
    cout<<"Size of long int: "<<sizeof(long int)<<endl;
    cout<<"Size of float: "<<sizeof(float)<<endl;
    cout<<"Size of double: "<<sizeof(double)<<endl;
    cout<<"Size of wchar_t: "<<sizeof(wchar_t)<<endl;
}

void variable_declaration()
{
    int a, b, c;
    float f;
    //actual initialization
    a=10;
    b=20;
    c=a+b;
    cout<<c<<endl;
    f=70.0/3.0;
    cout<<f<<endl;
}

void define_proprocessor()
{
    #define LENGTH 10
    #define WIDTH 5
    #define NEWLINE '\n'

    int area;

    area=LENGTH*WIDTH;
    cout<<area;
    cout<<NEWLINE;

}

void sign_unsigned_int()
{
    short int i; //a signed short integer
    short unsigned int j; //an unsigned short integer

    j=50000;
    i=j;
    cout<<i<<endl<<j<<endl;
}
