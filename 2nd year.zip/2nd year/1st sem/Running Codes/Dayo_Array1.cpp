#include <iostream>
#include <stdlib.h>

using namespace std;

void input(char characters[], int& size);
void remove_repeats(char characters[], int& size);

int main()
{
    int counter, size, A;
    char array[30];
    input(array,size);
    cout << "string : ";
    for( int i = 0; i < size; i++ )
    {
        cout << array[i];
    }
    cout <<"\n\n";
    cout << "After deleting the repeated characters..." << endl << endl;
    remove_repeats(array,size);
    cout << "string : ";
    for( int i = 0; i < size; i++ )
    {
        cout << array[i];
    }
    cout << "\n";
    return 0;
}

void input(char characters[], int& size)
{
    int counter = 0;
    cout << "Enter an array of characters (30 max): ";
    do
    {
        cin.get(characters[counter]);
        counter++;
    } while (characters[counter-1] != '\n');
    cout <<"\n";
    size = counter-1;
    cout << "size\t: " << size << endl;
}

void remove_repeats(char characters[], int& size)
{
    int counter=0;
    for (int a=0; a<size; a++)
    {
        for (int b=a+1; b<size; b++)
        {
            if (characters[a] == characters[b])
            {
                for (int c=b; c<size-1; c++)
                {
                    characters[c]= characters[c+1];
                }
                b--;
                size--;
            }
        }
    }
    cout << "size\t: " << size << endl;
}

