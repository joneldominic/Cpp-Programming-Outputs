//ttt.h
//Ron Baxter
// Feb 5, 2015

#include<string>
using namespace std;


#ifndef TTT_H
#define TTT_H

//struct
struct Player
	{
		string name;
		char symbol;
		int currentScore, tie;

		Player()
		{
			name = "Player";
			symbol = 'Z';
			currentScore = 0;
			tie = 0;
		}

	};

class TicTacToe
{
private:

	Player user[2];
	int currentWin;
	char board[3][3];
	char plays[9];
public:
	TicTacToe()
	{
		//player1
		user[0].name = "Player 1";
		user[0].symbol = 'X';

		//player2
		user[1].name = "Player 2";
		user[1].symbol = 'O';

		currentWin = 4;

		int temp = 49;

		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				board[i][j] = temp;
				plays[i*3+j] = board[i][j];
				temp++;
			}
		}
	}


	//setter
	void Reset(bool);
	void SetSymbol(char);
	void SetPlayerName();
	void SetPlayerSymbol();

	//getter
	void ChoosePosition();
	int CheckForWinner();
;


	//display
	void DisplayBoard();
	void DisplayScore(int);

};

#endif
