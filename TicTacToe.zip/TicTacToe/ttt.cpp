//ttt.cpp
//Ron Baxter
// Feb 5, 2015

#include"ttt.h"
#include<iostream>
#include<string>
#include<iomanip>
#include<cctype>
using namespace std;

//Globals
// identifies current player
int z =1;
// tracks turns
int turn = 0;

// resets board
void TicTacToe::Reset(bool resetWin)
	{
		//reset globals to ensure proper play order
	 	z=1;
		turn = 0;

		// reset board to 1-9
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				board[i][j] = plays[i*3+j];

			}
		}
		// clears scores when Start new match choosen
		if(resetWin)
		{
			for(int i=0; i<2; i++)
			{
				user[i].currentScore = 0;
				user[i].tie = 0;
				user[0].name = "Player 1";
				user[1].name = "Player 2";

			}
		}
	}

void TicTacToe::SetPlayerName()
	{
		cin.ignore();
		for(int i=0; i<2;i++)
		{
		cout<<"Enter name for "<<user[i].name<<" : ";
		getline(cin, user[i].name);
		cout<<endl;
		}
	}

void TicTacToe::SetPlayerSymbol()
	{
		for(int i=0; i<2;i++)
		{
		cout<<"Enter Symbol for "<<user[i].name<<" : ";
		cin>>user[i].symbol;
		user[i].symbol = (toupper(user[i].symbol));
		cout<<endl;

		while(!isalpha(user[i].symbol))
			{
			cout<<"Letters only.\nTry again : ";
			cin>>user[i].symbol;
			user[i].symbol = (toupper(user[i].symbol));
			cout<<endl;
			}
		}
	}

void TicTacToe::DisplayScore(int found)
	{

		if(found == 1 || found == 2)
		{
			user[found-1].currentScore++;
			cout<<user[found-1].name<<" Wins!\n\n";
		}
		else if(found == 3)
		{
			user[0].tie++;
			cout<<"\nIt's a Tie\n\n";
		}


		cout<<user[0].name<<" Wins\t"<<user[1].name<<" Wins\t Tie Games\n";
		cout<<"*******************************************\n";
		cout<<setw(7)<<user[0].currentScore<<setw(17)<<user[1].currentScore<<setw(14)<<user[0].tie<<endl;
		cout<<endl<<endl;
	}

void TicTacToe::ChoosePosition()
{
	// to hold player selected move
	int move = 0;
	// used for move validation
	bool play = true;

		//manipulates z to change player
		if(z == 1)
		{
			z--;
		}
		else if(z == 0)
		{
			z++;
		}

		//repeates player turn till valid move
		do
		{
			// gets player move
			cout<<user[z].name<<" it's your turn."<<endl;
			cout<<"Select your move: ";
			cin>>move;
			cout<<endl;
			play = true;

		/*for(int i=0;i<3;i++)
			{int p = 0;
				for(int j=0;j<3;j++)
				{
					int o = 0;

					int equal = i*3+j+1;

					if(move == equal && board[i][j] == (char)equal)
					{
						board[i][j] = user[z].symbol;
						//break;
					}
					else if(cin.fail() || move<1 || move>9)
					{
						if(p == 2 && o == 2)
						{
						cin.clear();
						cin.ignore();
						cout<<"Invalid selection.\n\n";
						play= false;
						//break;
						}
					}
					else
					{
						if(p == 2 && o == 2)
						{
						cout<<"Position " <<move<<" already taken.\n\n";
						play = false;
						//break;
						}
					}

				}p++;
			}*/

					//check for move and if space is already taken
					if((move == 1) && (board[0][0] != user[0].symbol && board[0][0] != user[1].symbol))
					{
					board[0][0] = user[z].symbol;
					}
					else if((move == 2) && (board[0][1] != user[0].symbol && board[0][1] != user[1].symbol))
					{
					board[0][1] = user[z].symbol;
					}
					else if((move == 3) && (board[0][2] != user[0].symbol && board[0][2] != user[1].symbol))
					{
					board[0][2] = user[z].symbol;
					}
					else if((move == 4) && (board[1][0] != user[0].symbol && board[1][0] != user[1].symbol))
					{
					board[1][0] = user[z].symbol;
					}
					else if((move == 5) && (board[1][1] != user[0].symbol && board[1][1] != user[1].symbol))
					{
					board[1][1] = user[z].symbol;
					}
					else if((move == 6) && (board[1][2] != user[0].symbol && board[1][2] != user[1].symbol))
					{
					board[1][2] = user[z].symbol;
					}
					else if((move == 7) && (board[2][0] != user[0].symbol && board[2][0] != user[1].symbol))
					{
					board[2][0] = user[z].symbol;
					}
					else if((move == 8) && (board[2][1] != user[0].symbol && board[2][1] != user[1].symbol))
					{
					board[2][1] = user[z].symbol;
					}
					else if((move == 9) && (board[2][2] != user[0].symbol && board[2][2] != user[1].symbol))
					{
					board[2][2] = user[z].symbol;
					}
					//Invalidates anything but 1-9
					else if(cin.fail() || move<1 || move>9)
					{
						cin.clear();
						cin.ignore();
						cout<<"Invalid selection.\n\n";
						play= false;
					}
					//if position already taken
					else
					{
					cout<<"Position " <<move<<" already taken.\n\n";
					play = false;
					}
		}while(!play);

	}

int TicTacToe::CheckForWinner()
	{
	int winner = 0;
	turn++;
	cout<<turn<<endl;

	if(board[0][0] == board[1][1] && board[0][0] == board[2][2])
		{
			if(board[0][0] == user[z].symbol)
			{
			winner = z+1;
			}

			else if(board[0][0] == user[z].symbol)
			{
			winner = z+1;
			}
		}

	else if(board[2][0] == board[1][1] && board[2][0] == board[0][2])
		{
			if(board[2][0] == user[z].symbol)
			{
			winner = z+1;
			}

			else if(board[2][0] == user[z].symbol)
			{
			winner = z+1;
			}
		}

	else if(board[0][0] == board[0][1] && board[0][0] == board[0][2])
		{
			if(board[0][0] == user[z].symbol)
			{
			winner = z+1;
			}

			else if(board[0][0] == user[z].symbol)
			{
			winner = z+1;
			}
		}

	else if(board[1][0] == board[1][1] && board[1][0] == board[1][2])
		{
			if(board[1][0] == user[z].symbol)
			{
			winner = z+1;
			}

			else if(board[1][0] == user[z].symbol)
			{
			winner = z+1;
			}
		}

	else if(board[2][0] == board[2][1] && board[2][0] == board[2][2])
		{
			if(board[2][0] == user[z].symbol)
			{
			winner = z+1;
			}

			else if(board[2][0] == user[z].symbol)
			{
			winner = z+1;
			}
		}

	else if(board[0][0] == board[1][0] && board[0][0] == board[2][0])
		{
			if(board[1][0] == user[z].symbol)
			{
			winner = z+1;
			}

			else if(board[1][0] == user[z].symbol)
			{
			winner = z+1;
			}
		}

	else if(board[0][1] == board[1][1] && board[0][1] == board[2][1])
		{
			if(board[0][1] == user[z].symbol)
			{
			winner = z+1;
			}

			else if(board[0][1] == user[z].symbol)
			{
			winner = z+1;
			}
		}

	else if(board[0][2] == board[1][2] && board[0][2] == board[2][2])
		{
			if(board[0][2] == user[z].symbol)
			{
			winner = z+1;
			}

			else if(board[0][2] == user[z].symbol)
			{
			winner = z+1;
			}
		}
		else if(turn == 9)
		{
			winner = 3;
		}
		else
		{
			winner = 0;
		}
	return winner;
	}



void TicTacToe::DisplayBoard()
	{
		for(int i=0;i<3;i++)
		{
			cout<<"\t";
			for(int j=0;j<3;j++)
			{
				if(j == 2)
				cout<<board[i][j];
				else
				cout<<board[i][j]<<" | ";
			}
				if(i<2)
				{
					cout<<"\n\t---------\n";
				}
		}
		cout<<endl<<endl;
	}










