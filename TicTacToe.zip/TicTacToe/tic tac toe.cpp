#include"ttt.cpp"
#include<iostream>
#include<string>
#include<iomanip>
#include<cctype>
#include<stdlib.h>
using namespace std;


// prototypes

// type: int
// paramaters: none
// purpose: Display Main Menu
int MainMenu();


int main ()
{
    system("title @JTapang Creations");
	// to hold selection from main menu
	int menuSelect = 0;
	int findWin = 0;

	TicTacToe ttt1;

	cout<<"\n\t\t  Jonel Tapang - Tic Tac Toe\n";
	cout<<"\t\t   (*********************)\n";
	do
	{
		bool resetWin = false;

		menuSelect = MainMenu();

		if(menuSelect == 3)
		{
			break;
		}
		else if(menuSelect == 1)
		{
			resetWin = true;
		}

		ttt1.Reset(resetWin);

		if(menuSelect == 1)
		{
			ttt1.SetPlayerName();

			ttt1.SetPlayerSymbol();
		}

	for(int i = 0; i<=9;i++)
		{
		ttt1.DisplayBoard();

		ttt1.ChoosePosition();

		findWin = ttt1.CheckForWinner();

		if(findWin == 1 || findWin == 2 || findWin == 3)
			{
			break;
			}
		}

		ttt1.DisplayBoard();

		ttt1.DisplayScore(findWin);

	}while( menuSelect != 3);

return 0;
}





int MainMenu()
{
	int select = 0;

	cout<<"Main Menu\n";
	cout<<"********************************************************\n";
	cout<<" 1) Start a new match (two new players).\n";
	cout<<" 2) Continue the current match (same two players).\n";
	cout<<" 3) Exit.\n\n";

	cout<<"Enter your choice:";
	cin>>select;
	cout<<endl;

	while(cin.fail() || select <1 || select >3)
	{
		cin.clear();
		cin.ignore();
		cout<<"Please enter a valid choice : ";
		cin>>select;
	}

	return select;
}
