#include <iostream>
using namespace std;

int  time,hr,mins;
char status;
void output();

int input_hr_check(int hr)
{
    if ((hr > 24 || hr < 12) || ( hr == 24 && mins !=0))
    {
        cout<<endl<<"Error: Invalid time value."<<endl;
        cout<<"Enter a valid one."<<endl<<endl;
        output();   //false = means invalid
    }
    return hr;
}

int input_mins_check(int mins)
{
    if (mins > 60 || mins < 0)
    {
        cout<<endl<<"Error: Invalid time value."<<endl;
        cout<<"Enter a valid one."<<endl<<endl;
        output(); //false = means invalid
    }
    return mins;
}

int hr_converter(int hr)
{
    int converted_hr;

    if(hr>12)
    {
         converted_hr=input_hr_check(hr)-12;
    }
    else if (hr==12)
    {
        converted_hr=input_hr_check(hr);
    }
    return converted_hr;
}

char identifier(char status)
{
    if (input_hr_check(hr)<=12)
    {
        return 'A';
    }
    else
        return 'P';
}

void display()
{
    cout<<"It's "<<hr_converter(hr)<<":";
    if(input_mins_check(mins)<10)
    {
        cout<<"0";
    }
    cout<<input_mins_check(mins);

    if (identifier(status)=='A')
    {
        cout<<" A.M."<<endl;
    }
    else
    {
        cout<<" P.M."<<endl;
    }

}

void output()
{
    cout<<"Enter time in 24-hr format (hh mm): ";
    cin>>hr>>mins;
    input_hr_check(hr);
    input_mins_check(mins);
    display();
}

int main()
{
    char choice;

    do
    {
        output();
        cout<<endl<<"Continue to input another time? [y|n] ";
        cin>>choice;
        cout<<endl;
    }while (choice=='Y'|| choice=='y');
    return 0;
}

