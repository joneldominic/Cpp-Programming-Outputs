#include <iostream>
using namespace std;


void prime_display();
int finder(int xnum);
int counter,line_break=0;


int main()
{
    prime_display();
    return 0;
}


void prime_display()
{
    for(int xnum=1;xnum<=100;xnum++)
    {
        counter = 0;
        finder(xnum);

    }
}
int finder(int xnum)
{
    for(int modnum=1;modnum<=xnum;modnum++)
        {
            if(xnum%modnum==0)
            {
                counter++;
            }
        }

        if(counter==2)
        {
            cout<<xnum<<"\t";
            line_break++;
        }

        if(line_break==5)
        {
            cout<<endl;
            line_break=0;
        }
        return xnum;
}


