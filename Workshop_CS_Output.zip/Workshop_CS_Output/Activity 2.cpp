#include <iostream>
#include <cctype>
#include <string>


using namespace std;

void display();
string identifier(string input);

void display()
{
    string input;
    cout<<"Enter an array of different characters [sysmbols accepter]: ";
    cin>>input;

    cout<<sizeof(input);

    for(int index=0;index<=(sizeof(input));index++)
    {
        cout<<input<<endl;
    }
    cout<<endl<<&input<<endl;
    //cout<<input.size();

}

string identifier(char input)
{

}


int main()
{
    display();

    return 0;
}
