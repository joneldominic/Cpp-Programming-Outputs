#include <iostream>
using namespace std;

void display();
int input_checker(int input);
int input,cent,quart,dime,penny;

int quart_converter(int quart)
{
    cent=input_checker(input);
    quart=cent/25;
    return quart;
}

int dime_converter(int dime)
{
    cent=input_checker(input);
    dime=(cent%25)/10;
    return dime;
}

int penny_converter(int penny)
{
    cent=input_checker(input);
    penny=((cent%25)%10)/1;
    return penny;
}

int input_checker(int input)
{
    if (input<1 || input>99)
    {
        cout<<"Error: Invalid amount, range is from 1 to 99. "<<endl;
        display();
    }
    return input;
}

void display()
{
    cout<<"Enter the amount of change (from 1-99): ";
    cin>>input;
    input_checker(input);
    cout<<endl;
    cout<<input<<" cents can be given as"<<endl;
    cout<<quart_converter(quart)<<" quarter(s) ";
    cout<<dime_converter(dime)<<" dime(s) ";
    cout<<penny_converter(penny)<<" penny(pennies)";
    cout<<endl;

}

int main()
{
    char choice;
    do
    {
         display();
         cout<<endl;
         cout<<"Do you want to enter another amount? [y|n] ";
         cin>>choice;
         cout<<endl;

    }while (choice=='y' || choice=='Y');


    return 0;
}
