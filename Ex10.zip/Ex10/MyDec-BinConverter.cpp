#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;



int sum;
int rem;
int decim;
int num = 1;
char choice;

int main()
{

            system ("cls");
            cout<<"\n**********************************You pressed(2)**********************************"<<endl;
            cout<<"Decimal to binary conversion..."<<endl<<endl;
            cout<<"Enter a decimal number: ";
            cin>>decim;
            cout<<endl;
            cout<<"Decimal number "<<decim<< " is equal to ";

            do{
                    rem = (decim%2);
                    sum = sum + (num*rem);
                    decim = decim/2;
                    num = num * 10;
            }
                while (decim>>0);


                cout<<sum<<" in binary";
                cout<<endl<<endl;


return 0;
}
cout<<"\n********************************** Dec - Bin **********************************"<<endl;
